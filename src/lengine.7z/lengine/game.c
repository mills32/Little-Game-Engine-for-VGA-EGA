#include "game.h"

int A = 0;
int B = 90;
int C = 180;
int i = 0;
int x = 0;
int y = 0;
int frame = 0;
int speed = 0;

int map[20*13] =
{
68,117,117,117,117,117,117,117,117,117,117,117,117,117,117,117,117,117,117,117,
117,2,3,47,51,52,34,35,36,37,47,47,47,8,9,10,11,47,47,117,
117,30,16,69,64,65,47,48,49,50,47,47,47,21,22,23,24,47,47,117,
117,28,29,106,47,47,20,47,47,80,33,80,47,34,35,36,37,47,20,117,
117,47,47,47,47,106,47,40,41,41,42,47,47,47,48,49,50,47,51,117,
117,106,106,106,78,106,106,66,44,54,55,78,47,106,106,106,81,20,64,117,
117,13,20,47,47,51,52,47,66,67,68,105,106,12,13,79,95,80,20,117,
117,26,9,10,11,64,65,45,46,47,77,47,47,25,26,92,106,106,106,117,
117,21,22,23,24,47,47,58,59,47,47,47,47,1,2,3,47,7,47,117,
117,34,35,36,37,47,69,47,47,47,51,52,47,14,30,17,2,3,78,117,
117,47,48,49,50,47,20,47,77,47,64,65,47,27,5,15,4,29,8,117,
117,47,47,47,78,47,47,47,47,47,47,20,47,47,27,28,29,47,21,117,
117,117,117,117,117,117,117,117,117,117,117,117,117,117,117,117,117,117,117,117
};


void mierda(int *map){
	int kk = map[0];
}

void main(){
	
	SPRITE sprite,sprite1,sprite2,sprite3,sprite4,sprite5;
	printf("Loading data from tileset");
	load_tiles("tileset.bmp",&tileset);		/* Load a tileset*/
	printf("Loading sprite");
	load_tiles("sprite.bmp",&spr1);		/* Load data for the sprite 1*/
	load_sprite(&sprite,&spr1);			/* init the sprite 1 with spr1 data*/
	load_sprite(&sprite1,&spr1);		/* init the sprite 1 with spr1 data*/
	load_sprite(&sprite2,&spr1);
	load_sprite(&sprite3,&spr1);
	load_sprite(&sprite4,&spr1);
	load_sprite(&sprite5,&spr1);
	
	set_mode(0x13);       /* set the video mode. */
	set_palette(&tileset.palette);
	/*outport(0x03c4,0xff02);
	memset(&VGA[0],0,(320*200)/4);*/
	
	//draw_bitmap(&tileset,0,0);
	
	draw_map(map,&tileset,20,13);
	
	/*start=*my_clock;
	//for (i = 0;i<600;i++) update_tiles();
	t1=(*my_clock-start)/18.2;
	start=*my_clock;
	//for (i = 0;i<600;i++) update_tiles2();
	t2=(*my_clock-start)/18.2;	
	*/
	i=0;
	/*MAIN LOOP SCROLL X*/
	while(i < 600){
		
		if (A == 360) A = 0;
		if (B == 360) B = 0;
		if (C == 360) C = 0;
		
		if(frame == 6) frame = 0;
	
		draw_sprite(&sprite,x+8,SIN[A],frame);
		draw_sprite(&sprite1,x+40,SIN[B],frame);
		draw_sprite(&sprite2,x+80,SIN[C],frame);
		/*draw_sprite(&sprite3,x+120,SIN[A],frame);
		draw_sprite(&sprite4,x+150,SIN[B],frame);
		draw_sprite(&sprite5,x+180,SIN[C],frame);*/
		
		//update_tiles2();
		//wait vbl
		VGA_Scroll(x,0);
		x++;
		A++;B++;C++;
		i++;
		if(speed == 10){speed = 0; frame++;}
		speed++;
	}
	
	free(tileset.data);                     /* free up memory used */
	free(sprite.data);
	set_mode(TEXT_MODE);                /* set the video mode back totext mode.*/
	printf("Copy bmp = %f\n",t1);
	printf("Copy spr = %f\n",t2);

	return;
}
