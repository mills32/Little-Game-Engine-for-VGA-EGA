#include "game.h"

int A = 0;
int B = 90;
int C = 180;
int i = 0;
int j = 0;
int x = 0;
int y = 0;
int frame = 0;
int speed = 0;

void mierda(int *map){
	map[0] = 1;
	map[1] = 0;
	
}

void main(){
	
	SPRITE sprite,sprite1,sprite2,sprite3,sprite4,sprite5;
	MAP testmap;
	
	printf("Loading data from tileset\n");
	load_tiles("tileset.bmp",&tileset);		/* Load a tileset*/
	printf("Loading sprites\n");
	load_tiles("sprite.bmp",&spr1);		/* Load data for the sprite 1*/
	load_sprite(&sprite,&spr1);			/* init the sprite 1 with spr1 data*/
	load_sprite(&sprite1,&spr1);		/* init the sprite 1 with spr1 data*/
	load_sprite(&sprite2,&spr1);
	load_sprite(&sprite3,&spr1);
	load_sprite(&sprite4,&spr1);
	load_sprite(&sprite5,&spr1);
	
	printf("Loading map\n");
	load_map("map.tmx",&testmap);
	
	set_mode(0x13);       /* set the video mode. */
	set_palette(&tileset.palette);
	
	//draw map at y = 12 (11 tiles height)
	for (i = 0;i<320;i+=16){
		draw_map_column(testmap,&tileset,i,12,j);
		j+=2;
	}
	
	/*start=*my_clock;
	for (i = 0;i<600;i++) ;
	t1=(*my_clock-start)/18.2;
	start=*my_clock;
	for (i = 0;i<600;i++) ;
	t2=(*my_clock-start)/18.2;	
	*/
	i=0;
	/*MAIN LOOP SCROLL X*/
	while(i < 800){
		
		if (A == 360) A = 0;
		if (B == 360) B = 0;
		if (C == 360) C = 0;
		
		if(frame == 6) frame = 0;
	
		draw_sprite(&sprite,x+8,SIN[A],frame);
		draw_sprite(&sprite1,x+40,SIN[B],frame);
		draw_sprite(&sprite2,x+80,SIN[C],frame);
		draw_sprite(&sprite3,x+120,SIN[A],frame);
		draw_sprite(&sprite4,x+150,SIN[B],frame);
		draw_sprite(&sprite5,x+180,SIN[C],frame);
		draw_map_column(testmap,&tileset,16,12,2);
		//wait vbl
		VGA_Scroll(x,0);
		x++;
		A++;B++;C++;
		i++;
		if(speed == 5){speed = 0; frame++;}
		speed++;
	}
	
	free(tileset.tdata);                     /* free up memory used */
	free(sprite.data);
	free(testmap.data);
	set_mode(TEXT_MODE);                /* set the video mode back totext mode.*/
	printf("Copy bmp = %f\n",t1);
	printf("Copy spr = %f\n",t2);

	return;
}
