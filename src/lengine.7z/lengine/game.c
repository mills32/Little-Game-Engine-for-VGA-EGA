/***********************
*  LITTLE GAME ENGINE  *
************************/
#include "game.h"

extern IMFsong song,song1,song2;				//Ok... 3 songs in memory just in case... 
extern TILE bmp0,tileset,spr1,spr2,spr3;				// 1 tileset and 3 different sprites
extern SPRITE sprite,sprite1,sprite2,sprite3,sprite4,sprite5;
extern MAP testmap;
extern float t1,t2;

int i = 0;
int j = 0;

int frame = 0;
int frame1 = 0;
int speed = 0;
int Scene = 0;

void mierda(int *map){
	map[0] = 1;
	map[1] = 0;
}

void main(){
	system("cls");
	//check_hardware();
	
	load_tiles("GFX/logo.bmp",&tileset);
	load_map("GFX/logo.tmx",&testmap);
	set_mode(0x13); set_palette(&tileset.palette);
	//draw map 
	for (i = 0;i<304;i+=16){
		draw_map_column(testmap,&tileset,i,0,j);
		j++;
	}
	wait(20);
	i = 0;
	//while(!kbhit()){ 
		//if (i == 184) i = 0;
		//word_out(0x03d4, V_RETRACE_END, 0x2c);
		//outp(MISC_OUTPUT, 0xe7);
		//word_out(0x03d4,H_DISPLAY_END, (256/4)-1);   	
		//word_out(0x03d4,V_DISPLAY_END, i);		
		//word_out(0x03d4,H_RETRACE_START,i); /**/ 
		//word_out(0x03d4, 0x13, (i>>2)-1);    		/* OFFSET			*/
		//while(inportb(0x3DA)&8);
		//while(!(inportb(0x3DA)&8)); // Make sure we change only once per line(1)/frame(8) 
		//i++;
	//}
	//word_out(0x03d4,H_DISPLAY_END, 0x4b);   	//HORIZONTAL RESOLUTION = 304  
	//word_out(0x03d4,V_DISPLAY_END, 0x73); 	//VERTICAL RESOLUTION = 184
	//word_out(0x03d4, V_RETRACE_END, 0x8e);
	free(&tileset); 
	i = 0;
	
	load_tiles("GFX/tileset.bmp",&tileset);		/* Load a tileset*/
	load_tiles("GFX/sprite.bmp",&spr1);		/* Load data for the sprite 1*/
	load_sprite(&sprite,&spr1);			/* init the sprite 1 with spr1 data*/
	load_sprite(&sprite1,&spr1);		/* init the sprite 1 with spr1 data*/
	load_sprite(&sprite2,&spr1);
	load_sprite(&sprite3,&spr1);
	load_sprite(&sprite4,&spr1);
	load_sprite(&sprite5,&spr1);
	
	sprite.pos_x = 160;
	sprite.pos_y = 100;
	
	load_map("GFX/map.tmx",&testmap);
	set_mode(0x13); set_palette(&tileset.palette);
	//draw map 
	j=0;
	for (i = 0;i<320;i+=16){
		draw_map_column(testmap,&tileset,i,0,j);
		j++;
	}
	
	
	
	//open IMF
	//"music/64style.imf" "music/fox.imf" "music/game.imf" "music/luna.imf" "music/menu.imf" "music/riddle.imf" "music/space.imf"
	set_timer(580); 
	Load_Song("music/menu.imf");
	opl2_clear();

	/*start=*my_clock;
	for (i = 0;i<600;i++) ;
	t1=(*my_clock-start)/18.2;
	start=*my_clock;
	for (i = 0;i<600;i++) ;
	t2=(*my_clock-start)/18.2;	
	*/

	/*MAIN LOOP SCROLL X*/
	while(Scene == 0){

		if(frame == 6) frame = 0;
	
		draw_sprite(&sprite,sprite.pos_x,sprite.pos_y,frame);
		draw_sprite(&sprite1,80,20,frame1);
		draw_sprite(&sprite2,200,150,frame1);

		//wait vbl
		MCGA_Scroll(sprite.pos_x-160,sprite.pos_y-100);

		if(speed == 5){speed = 0; frame++;}
		
		//move sprite
		if (read_keys() == 0){sprite.pos_y--; sprite.base_frame = 12; speed++;}
		if (read_keys() == 1){sprite.pos_y++; sprite.base_frame = 18; speed++;}
		if (read_keys() == 2){sprite.pos_x--; sprite.base_frame = 6 ; speed++; update_tilesL(testmap,&tileset);}
		if (read_keys() == 3){sprite.pos_x++; sprite.base_frame = 0 ; speed++; update_tilesD(testmap,&tileset);} 
		
		//sprite.pos_x++; speed++; update_tilesD(testmap,&tileset);
		if (read_keys() == 6) Scene = -1; //esc exit
	}
	reset_mode(TEXT_MODE); 
	
	opl2_clear();
	reset_timer();
	free(song.sdata);
	free(tileset.tdata);                     /* free up memory used */
	free(sprite.data);
	free(testmap.data);

	//debug
	//printf("Copy bmp = %f\n",t1);
	//printf("Copy spr = %f\n",t2);
	
	return;
}
