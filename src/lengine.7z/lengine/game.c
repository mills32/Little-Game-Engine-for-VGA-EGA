/***********************
*  LITTLE GAME ENGINE  *
************************/
#include "game.h"
	
TILE tileset_logo,tileset_level,tileset_space;			
SPRITE sprite_player,sprite_ship0,sprite_ship1,sprite_enemy1,sprite_enemy2,sprite_enemy3;
MAP map_logo,map_level,map_space;
COLORCYCLE cycle_water;

unsigned char palette_cycle_water[] = {//generated with gimp, then divided by 4 (max = 64).
	0x0f,0x0f,0x0f,	//colour 0
	//2 copies of 8 colour cycle
	0x35,0x3b,0x3f,//
	0x26,0x39,0x3f,
	0x18,0x36,0x3f,
	0x09,0x32,0x3e,
	0x0f,0x34,0x3f,
	0x17,0x36,0x3f,
	0x1c,0x3a,0x3e,
	0x24,0x3e,0x3d,
	0x35,0x3b,0x3f,//
	0x26,0x39,0x3f,
	0x18,0x36,0x3f,
	0x09,0x32,0x3e,
	0x0f,0x34,0x3f,
	0x17,0x36,0x3f,
	0x1c,0x3a,0x3e,
	0x24,0x3e,0x3d,
	0x35,0x3b,0x3f
};


int i = 0;
int j = 0;

int frame = 0;
int frame1 = 0;
int speed = 0;
int Scene = 0;


void main(){
	system("cls");
	//check_hardware();
	printf("Loading...\n");
	/*set_mode(0x13); 
	load_map("GFX/logo.tmx",&map_logo);
	load_tiles("GFX/logo.bmp",&tileset_logo);
	//draw map 
	for (i = 0;i<304;i+=16){
		draw_map_column(map_logo,&tileset_logo,i,0,j);
		j++;
	}
	
	set_palette(&tileset_logo.palette);
	
	i = 0;
	j = 0;
	while(Scene == 0){
		//outp(MISC_OUTPUT, 0xe7);
		//word_out(0x03d4,H_DISPLAY_END, (256/4)-1);   	
		//word_out(0x03d4,V_DISPLAY_END, i);
		//word_out(0x03d4, 0x13, (i>>2)-1);    		
		if (j >360) j = 0;
		for(i=0;i<360;i++){
			//word_out(0x03d4, V_RETRACE_END, 0x2c);
			//MCGA_Scroll2(SIN[i+j]);
			word_out(0x03d4, V_RETRACE_END, 0x2c);
			word_out(0x03d4,H_RETRACE_START,SIN[i+j]); 
			while(inportb(0x3DA)&1);
			while(!(inportb(0x3DA)&1)); // Make sure we change only once per line 
		}
		
		if (read_keys() == 6) Scene = 1;
		if (j == 100) Scene = 1;
		while(inportb(0x3DA)&8);
		while(!(inportb(0x3DA)&8)); 
		j++;
	}
	//word_out(0x03d4,H_DISPLAY_END, 0x4b);   	//HORIZONTAL RESOLUTION = 304  
	//word_out(0x03d4,V_DISPLAY_END, 0x73); 	//VERTICAL RESOLUTION = 184
	//word_out(0x03d4, V_RETRACE_END, 0x8e);
	free(&tileset_logo);
	free(&map_logo);
	*/
	Scene = 1;

	i = 0;
	j = 0;
	set_mode(0x13); 
	load_tiles("GFX/stileset.bmp",&tileset_space);		/* Load a tileset*/
	load_RLE_sprite("GFX/sprite.bmp",&sprite_player,16);
	load_RLE_sprite("GFX/ship0.bmp",&sprite_ship0,32);
	load_RLE_sprite("GFX/ship1.bmp",&sprite_ship1,32);
	
	sprite_ship1.pos_x = 130;
	sprite_ship1.pos_y = 70;
	
	set_palette(&tileset_space.palette);
	
	load_map("GFX/smap.tmx",&map_space);

	//draw map 
	j=0;
	for (i = 0;i<320;i+=16){
		draw_map_column(map_space,&tileset_space,i,0,j);
		j++;
	}

	start=*my_clock;
	for (i = 0;i<100;i++) draw_RLE_sprite(&sprite_ship0,0,0,0);
	t1=(*my_clock-start)/18.2;
	start=*my_clock;
	for (i = 0;i<100;i++) draw_RLE_sprite(&sprite_ship1,0,0,0);
	t2=(*my_clock-start)/18.2;	


	//open IMF
	//"music/64style.imf" "music/fox.imf" "music/game.imf" "music/luna.imf" "music/menu.imf" "music/riddle.imf" "music/space.imf"
	set_timer(580); 
	Load_Song("music/menu.imf");
	opl2_clear();	
	
	//animate colours
	cycle_init(&cycle_water,&palette_cycle_water);

	i = 0;
	j = 0;
	
	/*MAIN LOOP SCROLL X*/
	while(Scene == 1){
		cycle_palette(&cycle_water,2);
	
		if(frame == 2) frame = 0;
		if (i == 360) i = 0;

		//draw_RLE_sprite(&sprite_player,sprite_ship1.pos_x-32,50+SIN[i],2);
		draw_RLE_sprite(&sprite_ship1,sprite_ship1.pos_x,sprite_ship1.pos_y+SIN[i],frame);

		//wait vbl
		MCGA_Scroll(sprite_ship1.pos_x-130,sprite_ship1.pos_y-70);

		if(speed == 5){speed = 0; frame++;}
		
		//move sprite
		/*
		if (read_keys() == 0){sprite_player.pos_y--; sprite_player.base_frame = 12; speed++;}
		if (read_keys() == 1){sprite_player.pos_y++; sprite_player.base_frame = 18; speed++;}
		if (read_keys() == 2){sprite_player.pos_x--; sprite_player.base_frame = 6 ; speed++; update_tilesL(map_level,&tileset_level);}
		if (read_keys() == 3){sprite_player.pos_x++; sprite_player.base_frame = 0 ; speed++; update_tilesD(map_level,&tileset_level);} 
		*/
		sprite_ship1.pos_x++; speed++; update_tilesD(map_space,&tileset_space);
		if (read_keys() == 6) Scene = -1; //esc exit
		//if (j == 600) Scene = -1; //esc exit
		i++;j++;
	}
	reset_mode(TEXT_MODE); 
	
	opl2_clear();
	reset_timer();
	
	free(&song);
	free(&tileset_space);                     /* free up memory used */
	free(&map_space);
	free(&sprite_ship0);
	free(&sprite_ship1);
	free(&sprite_player);

	//debug
	printf("Copy rle odd = %f\n",t1);
	printf("Copy rle even = %f\n",t2);
	
	return;
}
