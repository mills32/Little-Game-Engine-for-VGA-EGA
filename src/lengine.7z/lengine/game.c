#include "game.h"

int A = 0;
int B = 90;
int C = 180;
int i = 0;
int x = 0;
int y = 0;
int frame = 0;
int speed = 0;

void draw_sprite2(SPRITE *spr, int x, int y, int frame);

int mierda;
int mierda1;
int mierda2;
void test(SPRITE *spr, int x, int y){
	mierda = x;
	mierda1 = y;
	mierda2 = spr->width;
	spr->bkg_data[0] = 0;
}

void main(){
	
	SPRITE sprite,sprite1,sprite2,sprite3,sprite4,sprite5;
	
	printf("Loading");
	load_bmp("map2.bmp",&tileset);		/* Load a tileset*/
	load_bmp("sprite.bmp",&spr1);		/* Load data for the sprite 1*/
	load_sprite(&sprite,&spr1);			/* init the sprite 1 with spr1 data*/
	load_sprite(&sprite1,&spr1);		/* init the sprite 1 with spr1 data*/
	load_sprite(&sprite2,&spr1);
	load_sprite(&sprite3,&spr1);
	load_sprite(&sprite4,&spr1);
	load_sprite(&sprite5,&spr1);
	
	set_mode(0x13);       /* set the video mode. */
	set_palette(&tileset.palette);
	/*outport(0x03c4,0xff02);
	memset(&VGA[0],0,(320*200)/4);*/
	
	draw_bitmap(&tileset,0,0);
	
	start=*my_clock;
	for (i = 0;i<600;i++)draw_sprite(&sprite,16,0,0);
	t1=(*my_clock-start)/18.2;
	start=*my_clock;
	for (i = 0;i<600;i++)draw_sprite2(&sprite,16,0,0);
	t2=(*my_clock-start)/18.2;	
	
	i=0;
	/*MAIN LOOP SCROLL X*/
	while(i < 600){
		
		if (A == 360) A = 0;
		if (B == 360) B = 0;
		if (C == 360) C = 0;
		
		if(frame == 6) frame = 0;
		
		draw_sprite2(&sprite,x+8,SIN[A],frame);
		draw_sprite2(&sprite1,x+40,SIN[B],frame);
		draw_sprite2(&sprite2,x+80,SIN[C],frame);
		/*draw_sprite(&sprite3,x+120,SIN[A],frame);
		draw_sprite(&sprite4,x+150,SIN[B],frame);
		draw_sprite(&sprite5,x+180,SIN[C],frame);*/
		
		/*update_tiles();*/
		/*wait vbl*/
		VGA_Scroll(0,0);
		x++;
		A++;B++;C++;
		i++;
		if(speed == 10){speed = 0; frame++;}
		speed++;
	}
	
	free(tileset.data);                     /* free up memory used */
	free(sprite.data);
	set_mode(TEXT_MODE);                /* set the video mode back totext mode.*/
	printf("Copy bmp = %f\n",t1);
	printf("Copy spr = %f\n",t2);

	return;
}
