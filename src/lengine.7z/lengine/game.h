/**************************************************************************
 * original bitmap.c by David Brackeen                                    *
 * http://www.brackeen.com/home/vga/                                      *
 *                                                                        *
 * This is a 16-bit program.                                              *                                              *
 * Remember to compile in the LARGE memory model!                         *
 *                                                                        *
 * This program is intended to work on MS-DOS, 8086/286, MCGA/VGA video   *
 *                                                                        *
 * Please feel free to copy this source code.                             *
 *                                                                        *
 * DESCRIPTION: This program demostrates drawing sprites                  *
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include <mem.h>
#undef outp
#define VIDEO_INT           0x10      /* the BIOS video interrupt. */
#define SET_MODE            0x00      /* BIOS func to set the video mode. */
#define VGA_256_COLOR_MODE  0x13      /* use to set 256-color mode. */
#define TEXT_MODE           0x03      /* use to set 80x25 text mode. */

#define SCREEN_WIDTH        320       /* width in pixels of mode 0x13 */
#define SCREEN_HEIGHT       200       /* height in pixels of mode 0x13 */
#define NUM_COLORS          256       /* number of colors in mode 0x13 */

#define H_TOTAL             0x00      /* CRT controller registers */
#define H_DISPLAY_END       0x01
#define H_BLANK_START       0x02
#define H_BLANK_END         0x03
#define H_RETRACE_START     0x04
#define H_RETRACE_END       0x05
#define V_TOTAL             0x06
#define OVERFLOW            0x07
#define MAX_SCAN_LINE       0x09
#define V_RETRACE_START     0x10
#define V_RETRACE_END       0x11
#define V_DISPLAY_END       0x12
#define OFFSET              0x13
#define UNDERLINE_LOCATION  0x14
#define V_BLANK_START       0x15
#define V_BLANK_END         0x16
#define MODE_CONTROL        0x17

/* macro to write a word to a port */
#define word_out(port,register,value) \
  outport(port,(((word)value<<8) + register))

typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned long  dword;

byte *VGA=(byte *)0xA0000000L;        /* this points to video memory. */
word *my_clock=(word *)0x0000046C;    /* this points to the 18.2hz system clock. */
word start;
float t1 = 0;
float t2 = 0;

typedef struct tagBITMAP              /* the structure for a bitmap. */
{
	word width;
	word height;
	byte *data;
	unsigned char palette[256*3];
} BITMAP;

BITMAP tileset,spr1,spr2,spr3;			/* 1 tileset and 3 different sprites*/

typedef struct tagSPRITE              /* the structure for a sprite. */
{
	word width;
	word height;
	byte *data;
	byte *bkg_data;
	int init; 
	int frames;
  	int last_x;
	int last_y;
} SPRITE;

/*VGA Hardware scroll*/
int pipa = 0; /*pixel panning*/
void VGA_Scroll(int x,int y)
{
	pipa = x;
	if (x > 7)pipa = pipa - (8*(pipa/8));
	
	x=x/4;
	/*if (x > 79) x = x - (80*(x/80));*/
	y=y*80;

  while ((inp(0x03da) & 0x08));
	/*change pixel panning register 3c0 during vertical retrace*/
	/*you CAN do 1 pixel horizontal scrolling with this*/ 
	inp(0x3da);
	outp(0x3c0, 0x33);		/*not working on PCEM ?*/
	outp(0x3c0, pipa*2);
	/*change scroll registers: HIGH_ADDRESS 0x0C; LOW_ADDRESS 0x0D */
	/*you CAN'T do 1 pixel horizontal scrolling with these*/
	/*Also change page with vertical scroll */
	outport(0x03d4, 0x0C | (x+y & 0xff00));
	outport(0x03d4, 0x0D | (x+y << 8));
  while (!(inp(0x03da) & 0x08));
}

int scroll = 0;
int scroll_pos = 304;
int fix = 0;
/*update screen column*/
void update_tiles(){
	int i;
	switch (scroll) {
		case 2: for (i = 0; i < 25; i++) memcpy(&VGA[scroll_pos+((i+fix)*320)],&tileset.data[scroll_pos+(i*320)],16); break;
		case 4: for (i = 25; i < 50; i++) memcpy(&VGA[scroll_pos+((i+fix)*320)],&tileset.data[scroll_pos+(i*320)],16); break;
		case 6: for (i = 50; i < 75; i++) memcpy(&VGA[scroll_pos+((i+fix)*320)],&tileset.data[scroll_pos+(i*320)],16); break;
		case 8: for (i = 75; i < 100; i++) memcpy(&VGA[scroll_pos+((i+fix)*320)],&tileset.data[scroll_pos+(i*320)],16); break;
		case 10: for (i = 100; i < 125; i++) memcpy(&VGA[scroll_pos+((i+fix)*320)],&tileset.data[scroll_pos+(i*320)],16); break;
		case 12: for (i = 125; i < 150; i++) memcpy(&VGA[scroll_pos+((i+fix)*320)],&tileset.data[scroll_pos+(i*320)],16); break;
		case 14: for (i = 150; i < 175; i++) memcpy(&VGA[scroll_pos+((i+fix)*320)],&tileset.data[scroll_pos+(i*320)],16); break;
		case 16: 
			scroll = 0; 
			scroll_pos+=16;
			if (scroll_pos == 320) {scroll_pos = 0; fix++;}
			for (i = 175; i < 200; i++) memcpy(&VGA[scroll_pos+((i+fix)*320)],&tileset.data[scroll_pos+(i*320)],16);
		break;
		default:break;
	}
	scroll++;
}

void fskip(FILE *fp, int num_bytes)
{
   int i;
   for (i=0; i<num_bytes; i++)
      fgetc(fp);
}

/**************************************************************************
 *  set_mode                                                              *
 *     Sets the video mode.                                               *
 **************************************************************************/

void set_mode(byte mode)
{
	union REGS regs;
	regs.h.ah = 0x00;
	regs.h.al = mode;
	int86(0x10, &regs, &regs);
	/*320x240*/
	/*outp(0x03c2, 0xe7);

	/*word_out(0x03d4,H_TOTAL, 80);  /**/             
	/*word_out(0x03d4,H_DISPLAY_END, 1024);  /**/      
	/*word_out(0x03d4,H_BLANK_START, 80); /**/        
	/*word_out(0x03d4,H_BLANK_END,0x60);  /**/         
	/*word_out(0x03d4,H_RETRACE_START, 80); /**/      
	/*word_out(0x03d4,H_RETRACE_END,0x80);/**/         
	/*word_out(0x03d4,V_TOTAL, 80);  /**/             
	/*word_out(0x03d4,OVERFLOW, 80);  /**/            
	/*word_out(0x03d4,MAX_SCAN_LINE,0);/**/         
	/*word_out(0x03d4,V_RETRACE_START, 0x000f); /**/      
	/*word_out(0x03d4,V_RETRACE_END, 0xffff); /**/        
	/*word_out(0x03d4,V_DISPLAY_END, 0x60); /*VERTICAL RESOLUTION = 168*/  
	/*word_out(0x03d4,UNDERLINE_LOCATION, 80); /**/   
	/*word_out(0x03d4,V_BLANK_START, 80);   /**/      
	/*word_out(0x03d4,V_BLANK_END, 80);    /**/      
    /*word_out(0x03d4,MODE_CONTROL, 80);  /**/     
	/*word_out(0x03d5, 0x13, 40);    		/* OFFSET			*/
	
	
	/*word_out(0x03d4,0x00,0x5F);/**/
	/*word_out(0x03d4,0x01,0x3F);/**/
	/*word_out(0x03d4,0x02,0x40);/**/
	/*word_out(0x03d4,0x03,0x82);/**/
	/*word_out(0x03d4,0x04,0x4E);/**/
    /*word_out(0x03d4,0x05,0x9A);/**/
	/*word_out(0x03d4,0x06,0x23);/**/
	/*word_out(0x03d4,0x07,0xB2);/**/
	/*word_out(0x03d4,0x08,0x00);/**/
	/*word_out(0x03d4,0x09,0x61);/**/
	/*word_out(0x03d4,0x10,0x0A);/**/
	/*word_out(0x03d4,0x11,0xAC);/**/
	/*word_out(0x03d4,0x12,0xFF);/**/
	/*word_out(0x03d4,0x13,0x20);/**/
    /*word_out(0x03d4,0x14,0x40);/**/
	/*word_out(0x03d4,0x15,0x07);/**/
	/*word_out(0x03d4,0x16,0x17);/**/
	/*word_out(0x03d4,0x17,0xA3);/**/
	/*word_out(0x03d4,0x18,0xFF);/**/
}

/* load_bmp */
void load_bmp(char *file,BITMAP *b)
{
	FILE *fp;
	long index;
	word num_colors;
	int x;

	fp = fopen(file,"rb");
	fgetc(fp);
	fgetc(fp);

	fskip(fp,16);
	fread(&b->width, sizeof(word), 1, fp);
	fskip(fp,2);
	fread(&b->height,sizeof(word), 1, fp);
	fskip(fp,22);
	fread(&num_colors,sizeof(word), 1, fp);
	fskip(fp,6);

	if (num_colors==0) num_colors=256;
	if ((b->data = (byte *) malloc((word)(b->width*b->height))) == NULL){
		fclose(fp);
		printf("Error allocating memory for file %s.\n",file);
		exit(1);
	}

	for(index=0;index<num_colors;index++){
		b->palette[(int)(index*3+2)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+1)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+0)] = fgetc(fp) >> 2;
		x=fgetc(fp);
	}

	for(index=(b->height-1)*b->width;index>=0;index-=b->width)
		for(x=0;x<b->width;x++)
		b->data[(word)index+x]=(byte)fgetc(fp);

	fclose(fp);
}

void load_sprite(SPRITE *s,BITMAP *b){
	s->data = b->data; 
	s->bkg_data = (byte *) malloc((word)(256)); /*allocate memory for the 16x16 bkg chunk erased every time you draw the sprite*/
	s->init = 0;
	s->height = b->height;
	s->width = b->width;
}


/*set_palette*/                                                           
void set_palette(unsigned char *palette)
{
  int i;
  outp(0x03c8,0); 
  for(i=0;i<256*3;i++) outp(0x03c9,palette[i]);
}

/* draw_bitmap */
void draw_bitmap(BITMAP *bmp,int x,int y)
{
  int j;
  word screen_offset = (y<<8)+(y<<6)+x;
  word bitmap_offset = 0;

  for(j=0;j<bmp->height;j++)
  {
    memcpy(&VGA[screen_offset],&bmp->data[bitmap_offset],bmp->width);

    bitmap_offset+=bmp->width;
    screen_offset+=SCREEN_WIDTH;
  }
}
int kk;
void cosita(SPRITE *spr){
	memcpy(&VGA[0],&spr->data[0],16);
}

void draw_sprite(SPRITE *s,int x,int y, int frame){
	int i = 0;
	int j = 0;
	word screen_offset; 
	word bitmap_offset = 16*frame; 
 
	/*Paste destroyed bkg chunk in last frame*/
	if (s->init == 1){
		i = 0;
		screen_offset = (s->last_y<<8)+(s->last_y<<6)+s->last_x;
		for(j=0;j<16;j++){
			memcpy(&VGA[screen_offset],&s->bkg_data[i],16);
			screen_offset+=SCREEN_WIDTH;
			i+=16;
		}
		s->init = 2;
	}
	s->init = 1;
	
	/*Copy bkg chunk before destroying it*/
	i = 0;
	screen_offset = (y<<8)+(y<<6)+x;
	for(j=0;j<16;j++){
		memcpy(&s->bkg_data[i],&VGA[screen_offset],16);
		screen_offset+=SCREEN_WIDTH;
		i+=16;
	}

	/*copy sprite and destroy bkg*/
	screen_offset = (y<<8)+(y<<6)+x;
	for(j=0;j<16;j++){
		memcpy(&VGA[screen_offset],&s->data[bitmap_offset],16);
		bitmap_offset+=s->width;
		screen_offset+=SCREEN_WIDTH;
	}
	s->last_x = x;
	s->last_y = y;
}

/*draw_transparent_bitmap */

void draw_transparent_bitmap(BITMAP *bmp,int x,int y)
{
  int i,j;
  word screen_offset = (y<<8)+(y<<6);
  word bitmap_offset = 0;
  byte data;

  for(j=0;j<bmp->height;j++)
  {
    for(i=0;i<bmp->width;i++,bitmap_offset++)
    {
      data = bmp->data[bitmap_offset];
      if (data) VGA[screen_offset+x+i] = data;
    }
    screen_offset+=SCREEN_WIDTH;
  }
}

/*wait*/

void wait(int ticks)
{
  word start;
  start=*my_clock;
  while (*my_clock-start<ticks){
    *my_clock=*my_clock;
  }
}

int SIN[360] = {
102, 103, 104, 105, 106, 107, 109, 110, 111, 112,
113, 114, 115, 116, 117, 119, 120, 121, 122, 123,
124, 125, 126, 127, 128, 129, 130, 131, 132, 133,
134, 135, 136, 137, 138, 139, 140, 140, 141, 142,
143, 144, 145, 145, 146, 147, 148, 149, 149, 150,
151, 151, 152, 153, 153, 154, 155, 155, 156, 156,
157, 157, 158, 158, 159, 159, 160, 160, 161, 161,
161, 162, 162, 162, 163, 163, 163, 163, 164, 164,
164, 164, 164, 164, 164, 164, 164, 164, 165, 164,
164, 164, 164, 164, 164, 164, 164, 164, 164, 163,
163, 163, 163, 162, 162, 162, 161, 161, 161, 160,
160, 159, 159, 158, 158, 157, 157, 156, 156, 155,
155, 154, 153, 153, 152, 151, 151, 150, 149, 149,
148, 147, 146, 145, 145, 144, 143, 142, 141, 140,
140, 139, 138, 137, 136, 135, 134, 133, 132, 131,
130, 129, 128, 127, 126, 125, 124, 123, 122, 121,
120, 119, 117, 116, 115, 114, 113, 112, 111, 110,
109, 107, 106, 105, 104, 103, 102, 101, 100, 98,
97, 96, 95, 94, 93, 92, 90, 89, 88, 87,
86, 85, 84, 83, 82, 80, 79, 78, 77, 76,
75, 74, 73, 72, 71, 70, 69, 68, 67, 66,
65, 64, 63, 62, 61, 60, 59, 59, 58, 57,
56, 55, 54, 54, 53, 52, 51, 50, 50, 49,
48, 48, 47, 46, 46, 45, 44, 44, 43, 43,
42, 42, 41, 41, 40, 40, 39, 39, 38, 38,
38, 37, 37, 37, 36, 36, 36, 36, 35, 35,
35, 35, 35, 35, 35, 35, 35, 35, 35, 35,
35, 35, 35, 35, 35, 35, 35, 35, 35, 36,
36, 36, 36, 37, 37, 37, 38, 38, 38, 39,
39, 40, 40, 41, 41, 42, 42, 43, 43, 44,
44, 45, 46, 46, 47, 48, 48, 49, 50, 50,
51, 52, 53, 54, 54, 55, 56, 57, 58, 59,
59, 60, 61, 62, 63, 64, 65, 66, 67, 68,
69, 70, 71, 72, 73, 74, 75, 76, 77, 78,
79, 80, 82, 83, 84, 85, 86, 87, 88, 89,
90, 92, 93, 94, 95, 96, 97, 98, 99, 101
};
