/*##########################################################################
	Original bitmap.c by David Brackeen                                   
	http://www.brackeen.com/home/vga/                                     

	This is a 16-bit program.                                                                                         *
	Remember to compile in the LARGE memory model!                        

	This program is intended to work on MS-DOS, 8086, MCGA (or VGA) video.     
	Yes you read well, an 8086 with an MCGA is capable of:
		- Store and display tiles to fill the entire screen (64 Kb of VRAM)
		- Hardware scrolling (yes, just 3 or 4 games used that).
		- Copy tiles from ram to the borders of the VRAM (very fast) to scroll around big maps.
		- Draw around 4 sprites (16x16 pixels) on top of the map.
		- Do all this keeping 60 FPS!!
	
	The "BAD" things
		- An 8086 can only draw 4 or 5 sprites without flickering
		- 304x184 resolution to hide the borders being updated, some monitors may not work.	
	
	Please feel free to copy this source code.                            

##########################################################################*/

#include "game.h"

//Predefined struct:
IMFsong song;	//Ok... 1 song in memory. 

//GLOBAL VARIABLES

//debugging
float t1 = 0;
float t2 = 0;

//This points to video memory.
byte *MCGA=(byte *)0xA0000000L; 

//timer     		
void interrupt (*old_time_handler)(void); 	
long time_ctr;

//ADLIB
const int opl2_base = 0x388;	
unsigned char shadow_opl[256];
long next_event;

// this points to the 18.2hz system clock. 
word *my_clock=(word *)0x0000046C;    		
word start;

//Hardware scrolling
int pipa = 0; //pixel panning

//Map Scrolling
int scrollD = 0;
int scroll_posD = 304;
int map_offsetD = 20;
int fixD = 0;
int scrollL = 0;
int scroll_posL = 304;
int map_offsetL = 20;
int fixL = 0;

//Sprite loader - rearrange a sprite sheet in memory
byte *sprite_datatemp; 
byte *sprite_tiledatatemp; 

//Tile loader - rearrange a tile sheet in memory
byte *tile_datatemp;

//end of global variables


int check_hardware(){
	asm{
		pushf                   // push original FLAGS
        pop     ax              // get original FLAGS
        mov     cx, ax          // save original FLAGS
        and     ax, 0fffh       // clear bits 12-15 in FLAGS
        push    ax              // save new FLAGS value on stack
        popf                    // replace current FLAGS value
        pushf                   // get new FLAGS
        pop     ax              // store new FLAGS in AX
        and     ax, 0f000h      // if bits 12-15 are set, then
        cmp     ax, 0f000h      //   processor is an 8086/8088
        je      _8086_8088		// jump if processor is 8086/8088
	}
	printf("\nCPU: 286+ - Little engine will work great!!\n");
	wait(30);
	return 0;
	_8086_8088:
	printf("\nCPU: 8088 - Little engine will work a bit slow\n");
	printf("\nCPU: 8086 - Little engine will work great!!\n (Just don't use more than 4 sprites)\n");
	wait(20);
	return 0;
}

int read_keys(){
	//Taken from commander keen source :)
	byte temp,k,key;
	k = inportb(0x60);	// Get the scan code
	// Tell the XT keyboard controller to clear the key
	outportb(0x61,(temp = inportb(0x61)) | 0x80);
	outportb(0x61,temp);
	switch (k){
		case 0x48: return 0; //UP
		case 0x50: return 1; //DOWN
		case 0x4B: return 2; //LEFT
		case 0x4D: return 3; //RIGHT
		case 0x20: return 4; //D (JUMP)
		case 0x1f: return 5; //S (ACTION)
		case 0x01: return 6; //ESC
		default: return -1;
	}
}

void MCGA_Scroll(int x,int y)
{
	pipa = x;
	if (x > 7)pipa = pipa - (8*(pipa/8));
	x=x/4;
	y=y*80;

  while ((inp(0x03da) & 0x08));
	/*change pixel panning register 3c0 during vertical retrace*/
	inp(0x3da);
	outp(0x3c0, 0x33);		
	outp(0x3c0, pipa*2);
	/*change scroll registers: HIGH_ADDRESS 0x0C; LOW_ADDRESS 0x0D */
	outport(0x03d4, 0x0C | (x+y & 0xff00));
	outport(0x03d4, 0x0D | (x+y << 8));
  while (!(inp(0x03da) & 0x08));
}

void MCGA_Scroll2(int x)
{
	x=x/4;
	/*change scroll registers: HIGH_ADDRESS 0x0C; LOW_ADDRESS 0x0D */
	outport(0x03d4, 0x0C | (x & 0xff00));
	outport(0x03d4, 0x0D | (x << 8));
}

void MCGA_ClearScreen(){
	outport(0x03c4,0xff02);
	memset(&MCGA[0],0,(320*200)/4);
}

void set_mode(byte mode)
{
	union REGS regs;
	regs.h.ah = 0x00;
	regs.h.al = mode;
	int86(0x10, &regs, &regs);
	//320x200
	// turn off write protect */
    word_out(0x03d4, V_RETRACE_END, 0x2c);
    outp(MISC_OUTPUT, 0xe7);
	
	/*word_out(0x03d4,H_TOTAL, 80);  /**/             
	word_out(0x03d4,H_DISPLAY_END, (304>>2)-1);   //HORIZONTAL RESOLUTION = 304   
	//word_out(0x03d4,H_BLANK_START, 0);        
	//word_out(0x03d4,H_BLANK_END,(320>>2)-1);         
	//word_out(0x03d4,H_RETRACE_START,3); /**/      
	//word_out(0x03d4,H_RETRACE_END,(320>>2)-1);        
	/*word_out(0x03d4,V_TOTAL, 80);  /**/             
	/*word_out(0x03d4,OVERFLOW, 80);  /**/            
	/*word_out(0x03d4,MAX_SCAN_LINE,0);/**/         
	//word_out(0x03d4,V_RETRACE_START, 0x0f); /**/      
	//word_out(0x03d4,V_RETRACE_END, 200); /**/        
	word_out(0x03d4,V_DISPLAY_END, 0x180); //VERTICAL RESOLUTION = 184
	/*word_out(0x03d4,UNDERLINE_LOCATION, 80); /**/   
	/*word_out(0x03d4,V_BLANK_START, 80);   /**/      
	/*word_out(0x03d4,V_BLANK_END, 80);    /**/      
    /*word_out(0x03d4,MODE_CONTROL, 80);  /**/     
	//word_out(0x03d4, 0x13, (320>>2)-1);    		/* OFFSET			*/
	
    // set vertical retrace back to normal
    word_out(0x03d4, V_RETRACE_END, 0x8e);
}

void reset_mode(byte mode)
{
	union REGS regs;
	regs.h.ah = 0x00;
	regs.h.al = mode;
	int86(0x10, &regs, &regs);
}

void fskip(FILE *fp, int num_bytes){
	int i;
	for (i=0; i<num_bytes; i++) fgetc(fp);
}

/* load plain bmp */
void load_plain_bmp(char *file,TILE *b)
{
	FILE *fp;
	long index;
	word num_colors;
	int x;

	fp = fopen(file,"rb");
	if(!fp){
		printf("can't find %s.\n",file);
		exit(1);
	}
	fgetc(fp);
	fgetc(fp);

	fskip(fp,16);
	fread(&b->width, sizeof(word), 1, fp);
	fskip(fp,2);
	fread(&b->height,sizeof(word), 1, fp);
	fskip(fp,22);
	fread(&num_colors,sizeof(word), 1, fp);
	fskip(fp,6);

	if (num_colors==0) num_colors=256;
	if ((b->tdata = (byte *) malloc(b->width*b->height)) == NULL){
		fclose(fp);
		printf("Error allocating memory for file %s.\n",file);
		exit(1);
	}

	for(index=0;index<num_colors;index++){
		b->palette[(int)(index*3+2)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+1)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+0)] = fgetc(fp) >> 2;
		x=fgetc(fp);
	}

	for(index=(b->height-1)*b->width;index>=0;index-=b->width)
		for(x=0;x<b->width;x++)
		b->tdata[(word)index+x]=(byte)fgetc(fp);

	fclose(fp);
}

/* load_16x16 tiles */
void load_tiles(char *file,TILE *b)
{
	FILE *fp;
	long index,offset;
	word num_colors;
	int x,i;
	int tileX;
	int tileY;
	byte *data;	//Temp storage of non tiled data.

	fp = fopen(file,"rb");
	if(!fp){
		printf("can't find %s.\n",file);
		exit(1);
	} 
	fgetc(fp);
	fgetc(fp);

	fskip(fp,16);
	fread(&b->width, sizeof(word), 1, fp);
	fskip(fp,2);
	fread(&b->height,sizeof(word), 1, fp);
	fskip(fp,22);
	fread(&num_colors,sizeof(word), 1, fp);
	fskip(fp,6);

	if (num_colors==0) num_colors=256;
	for(index=0;index<num_colors;index++){
		b->palette[(int)(index*3+2)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+1)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+0)] = fgetc(fp) >> 2;
		x=fgetc(fp);
	}
	
	if ((tile_datatemp = (byte *) malloc(b->width*b->height)) == NULL){
		fclose(fp);
		printf("Error allocating memory for temp data %s.\n",file);
		exit(1);
	}
	if ((b->tdata = (byte *) malloc(b->width*b->height)) == NULL){
		fclose(fp);
		printf("Error allocating memory tile data %s.\n",file);
		exit(1);
	}

	for(index=(b->height-1)*b->width;index>=0;index-=b->width)
		for(x=0;x<b->width;x++)
		tile_datatemp[(word)index+x]=(byte)fgetc(fp);
	fclose(fp);

	index = 0;
	
	//Rearrange tiles one after another in memory (in a column)
	for (tileY=0;tileY<b->height;tileY+=16){
		for (tileX=0;tileX<b->width;tileX+=16){
			offset = (tileY*b->width)+tileX;
			for(x=0;x<16;x++){
				memcpy(&b->tdata[index],&tile_datatemp[offset+(x*b->width)],16);
				index+=16;
			}
		}
	}
	b->ntiles = (b->width>>4) * (b->height>>4);
	b->width = 16;
	b->height = 200;
	free(tile_datatemp);
	tile_datatemp = NULL;
}

//Load tiled TMX map in XML format
void load_map(char *file, MAP *map){ 
	FILE *f = fopen(file, "rb");
	char *line = (char*) malloc (64);
	char *name = (char*) malloc (64); //name of the layer in TILED
	int start_data = 0;
	int end_data = 0;
	byte tile;
	int test = 0;
	word index = 0;
	if(!f){
		printf("can't find %s.\n",file);
		exit(1);
	}
	//read file
	fseek(f, 0, SEEK_SET);			
	while(start_data == 0){	//read lines 
		memset(line, 0, 64);
		fgets(line, 64, f);
		if((line[1] == '<')&&(line[2] == 'l')){
			sscanf(line," <layer name=\"%24[^\"]\" width=\"%i\" height=\"%i\"",&name,&map->width,&map->height);
			start_data = 1;
		}
	}
	if ((map->data = (byte *) malloc(map->width*map->height)) == NULL){
		fclose(f);
		printf("Error allocating memory for map\n");
		exit(1);
	}
	while(end_data == 0){
		memset(line, 0, 64);
		fgets(line, 64, f);
		if ((line[3] == '<')&&(line[4] == 't')){
			sscanf(line,"   <tile gid=\"%i\"/>",&tile);
			map->data[index] = tile -1;
			index++;
			test++;
		}
		if((line[2] == '<')&&(line[3] == '/'))end_data = 1;
	}
	map->ntiles = map->width*map->height;
	free(line);
	free(name);
}

void draw_map_column(MAP map, TILE *t, int x, int y, word map_offset){
	word *tiledata = &t->tdata;
	word *mapdata = map.data;
	word width = map.width;
	dword tile_offset = 0;
	word screen_offset = (y<<8)+(y<<6)+x;
	asm{
		push ds
		push di
		push si
		
		mov		dx,12		//11 tiles height column
		
		lds		bx,dword ptr[tiledata]					
		lds		si,ds:[bx]				//ds:si data address
		
		mov		word ptr [tile_offset],ds
		mov		word ptr [tile_offset+2],si

		mov		ax,map_offset
		les		bx,[mapdata]
		add		bx,ax
		mov		ax,es:[bx]
		mov		cl,8
		shl		ax,cl
		add		si,ax
		mov		di,screen_offset		//es:di screen address							
	}
	loop_tile:
	asm{
		mov 	ax,0A000h
		mov 	es,ax
		mov 	ax,16
	}
	copy_tile:	
	asm{
		mov 	cx,8
		rep		movsw				
		add 	di,320-16
		dec 	ax
		jnz		copy_tile
		
		mov		ds,word ptr [tile_offset]
		mov		si,word ptr [tile_offset+2]

		mov		ax,map_offset
		add		ax,[width]
		mov		map_offset,ax
		
		les		bx,[mapdata]
		add		bx,ax
		mov		ax,es:[bx]
		mov		cl,8
		shl		ax,cl
		add		si,ax
		
		dec		dx
		jnz		loop_tile
		
		pop si
		pop di
		pop ds
	}	
}

/*update screen column 304 20*/
void update_tilesD(MAP map, TILE *t){
	if (scrollD == 16) {
		scrollD = 0; 
		scroll_posD+=16;
		if (map_offsetD == map.width) map_offsetD = 0; 
		if (scroll_posD == 320) {scroll_posD = 0; fixD++;}
		//asm copy column at offset
		draw_map_column(map,t,scroll_posD,fixD,map_offsetD);
		map_offsetD++;
	}
	scrollD++;
}

/*update screen column*/
void update_tilesL(MAP map, TILE *t){
	if (scrollL == -16) {
		scrollL = 0; 
		scroll_posL-=16;
		if (map_offsetL < 0) map_offsetL = map.width; 
		if (scroll_posL < 0) {scroll_posL = 320; fixL--;}
		//asm copy column at offset
		draw_map_column(map,t,scroll_posL,fixL,map_offsetL);
		map_offsetL--;
	}
	scrollL--;
}

//sprites
void load_sprite(SPRITE *s,TILE *b){
	s->data = b->tdata; 
	s->bkg_data = (byte *) malloc(256); /*allocate memory for the 16x16 bkg chunk erased every time you draw the sprite*/
	s->init = 0;
	s->nframes = b->ntiles;
	s->base_frame = 0;
	s->frame = 0;
}

void draw_sprite(SPRITE *s,int x,int y, int frame){
	word *data = &s->data;
	word *bkg_data = &s->bkg_data;
	word screen_offset0 = (s->last_y<<8)+(s->last_y<<6)+s->last_x;
	word screen_offset1 = (y<<8)+(y<<6)+x;
	int init = s->init;
	s->frame = frame + s->base_frame;
	frame = s->frame<<8;
	
	asm{
		push ds
		push di
		push si
		
		/*Paste destroyed bkg chunk in last frame*/
		cmp	word ptr init,1 //if (s->init == 1)
		jne	short noinit
		
		mov 	ax,0A000h
		mov 	es,ax						
		mov		di,screen_offset0				
		
		lds		bx,[bkg_data]					
		lds		si,ds:[bx]						
		mov 	ax,16
	}
	copy_linea:	
	asm{
		mov 	cx,8
		rep		movsw				// copy 16 bytes from ds:si to es:di
		add 	di,320-16
		dec 	ax
		jnz		copy_linea
	}
	noinit:
	s->init = 1;
	
	/*Copy bkg chunk before destroying it*/
	asm{
		mov 	ax,0A000h
		mov 	ds,ax						
		mov		si,screen_offset1				
		
		les		bx,[bkg_data]					
		les		di,es:[bx]						
		mov 	ax,16
	}
	copy_lineb:	
	asm{
		mov 	cx,8
		rep		movsw				// copy 16 bytes from ds:si to es:di
		add 	si,320-16
		dec 	ax
		jnz		copy_lineb

	/*copy sprite and destroy bkg*/
		mov 	ax,0A000h
		mov 	es,ax						
		mov		di,screen_offset1				
		
		lds		bx,[data]					
		lds		si,ds:[bx]			
		mov		ax,[frame]				
		add		si,ax				
		mov 	ax,16
	}
	copy_linec:	
	asm{
		mov 	cx,8
		rep		movsw				// copy 16 bytes from ds:si to es:di
		add 	di,320-16
		dec 	ax
		jnz		copy_linec
		pop si
		pop di
		pop ds
	}
	
	s->last_x = x;
	s->last_y = y;
}

//load RLE sprites with transparency (size = 8,16,32)
void load_RLE_sprite(char *file,SPRITE *s,int size){
	FILE *fp;
	long index,offset;
	word num_colors;
	int x,y,i;
	int tileX;
	int tileY;
	byte *data;	//Temp storage of non tiled data.
	
	word number_of_runs = 0;
	int skip = 0;
	int pixel = 0; //this is to know if a scanline is empty
	word empty_scanline = 0; 
	word e_sskip = 0;
	word e_bskip = 0;
	word foffset = 0; //offset in final data
	word frame_size;
	word run_sskip[1024];
	word run_bskip[1024];
	word run_startx[1024];
	word run_length[1024];
	byte current_byte;
	byte last_byte = 0;
	
	fp = fopen(file,"rb");
	if(!fp){
		printf("can't find %s.\n",file);
		exit(1);
	} 
	fgetc(fp);
	fgetc(fp);

	fskip(fp,16);
	fread(&s->width, sizeof(word), 1, fp);
	fskip(fp,2);
	fread(&s->height,sizeof(word), 1, fp);
	fskip(fp,22);
	fread(&num_colors,sizeof(word), 1, fp);
	fskip(fp,6);

	if (num_colors==0) num_colors=256;
	for(index=0;index<num_colors;index++){
		s->palette[(int)(index*3+2)] = fgetc(fp) >> 2;
		s->palette[(int)(index*3+1)] = fgetc(fp) >> 2;
		s->palette[(int)(index*3+0)] = fgetc(fp) >> 2;
		x=fgetc(fp);
	}
	
	if ((sprite_datatemp = (byte *) malloc(s->width*s->height)) == NULL){
		fclose(fp);
		printf("Error allocating memory for temp data %s.\n",file);
		exit(1);
	}
	if ((sprite_tiledatatemp = (byte *) malloc(s->width*s->height)) == NULL){
		fclose(fp);
		printf("Error allocating memory tile data %s.\n",file);
		exit(1);
	}

	for(index=(s->height-1)*s->width;index>=0;index-=s->width)
		for(x=0;x<s->width;x++)
		sprite_datatemp[(word)index+x]=(byte)fgetc(fp);
	fclose(fp);

	index = 0;
	
	//Rearrange tiles one after another in memory (in a column)
	for (tileY=0;tileY<s->height;tileY+=size){
		for (tileX=0;tileX<s->width;tileX+=size){
			offset = (tileY*s->width)+tileX;
			for(x=0;x<size;x++){
				memcpy(&sprite_tiledatatemp[index],&sprite_datatemp[offset+(x*s->width)],size);
				index+=size;
			}
		}
	}
	s->nframes = (s->width>>4) * (s->height>>4);
	s->width = size;
	s->height = size;
	free(sprite_datatemp);
	sprite_datatemp = NULL;
	
	//CONVERT TO RLE 
	//You can surely do this loading pcx files, But I ended up doing it like this
	offset = 0;
	run_sskip[0] = 0;
	for(y = 0; y < size; y++) {
		last_byte = 0;
		pixel = 0;
		for(x = 0; x < size; x++) {
			current_byte = sprite_tiledatatemp[(size*y)+x];
			if (empty_scanline > 0){
				e_sskip = empty_scanline*320;
				e_bskip = empty_scanline*size;
			}
			else {
				e_sskip = 0;
				e_bskip = 0;
			}
			if (last_byte == 0 && current_byte > 0){
				pixel = 1;
				run_startx[number_of_runs] = x;
			}
			if (last_byte != 0 && current_byte == 0){
				run_length[number_of_runs] = x - run_startx[number_of_runs]; 
				if (number_of_runs == 0){
					run_sskip[0] = run_startx[0];
					run_bskip[0] = run_startx[0]+e_bskip;
				}
				if (number_of_runs > 0){
					if (skip == 0){
						run_sskip[number_of_runs] = e_sskip + run_startx[number_of_runs]-(run_startx[number_of_runs-1]+run_length[number_of_runs-1]);
						run_bskip[number_of_runs] = e_bskip + run_startx[number_of_runs]-(run_startx[number_of_runs-1]+run_length[number_of_runs-1]);
					}
					if (skip == 1){
						run_sskip[number_of_runs] = e_sskip + 320+run_startx[number_of_runs]-(run_startx[number_of_runs-1]+run_length[number_of_runs-1]);
						run_bskip[number_of_runs] = e_bskip + size+run_startx[number_of_runs]-(run_startx[number_of_runs-1]+run_length[number_of_runs-1]);
						skip = 0;
					}
					if (skip == 2){
						run_sskip[number_of_runs] = 320-size;
						run_bskip[number_of_runs] = 0;
						skip = 0;
					}
				}
				empty_scanline = 0;
				number_of_runs++;
			}
			last_byte = current_byte;
		}
		if (current_byte == 0) skip = 1;
		if (current_byte > 0){
			run_length[number_of_runs] = x -run_startx[number_of_runs];
			if (number_of_runs > 0){
				run_sskip[number_of_runs] = 320+run_startx[number_of_runs]-run_length[number_of_runs-1];
				run_bskip[number_of_runs] = size+run_startx[number_of_runs]-run_length[number_of_runs-1];
			}
			number_of_runs++;
			skip = 2;
		}
		if (pixel == 0) empty_scanline ++;
	}
	
	//calculate frames size
	s->rle_frames = (SPRITEFRAME*) malloc(s->nframes);
	
	frame_size = 2; //word "number of runs"
	for(i = 0; i < number_of_runs; i++) 
		frame_size+= (4 + run_length[i]); //word skip + word number of pixels + length
	s->rle_frames[0].rle_data = (byte *) malloc(frame_size);
	
	//copy RLE data to struct
	memcpy(&s->rle_frames[0].rle_data[0],&number_of_runs,2);
	foffset+=2;
	for(i = 0; i < number_of_runs; i++) {
		memcpy(&s->rle_frames[0].rle_data[foffset],&run_sskip[i],2); //bytes to skip on vga screen
		foffset+=2;
		memcpy(&s->rle_frames[0].rle_data[foffset],&run_length[i],2); //Number of bytes of pixel data that follow
		foffset+=2;
		offset+=run_bskip[i];
		memcpy(&s->rle_frames[0].rle_data[foffset],&sprite_tiledatatemp[offset],run_length[i]); //copy pixel data;
		foffset+=run_length[i];
		offset+=run_length[i];
	}

	free(sprite_tiledatatemp);
	sprite_tiledatatemp = NULL;
	
	s->bkg_data = (byte *) malloc(size*size); /*allocate memory for the 16x16 bkg chunk erased every time you draw the sprite*/
	s->init = 0;
	s->frame = 0;
}

void draw_RLE_sprite(SPRITE *s,int x,int y){
	dword *data = &s->rle_frames[0].rle_data;
	dword *bkg_data = &s->bkg_data;
	word screen_offset0 = (s->last_y<<8)+(s->last_y<<6)+s->last_x;
	word screen_offset1 = (y<<8)+(y<<6)+x;
	word init = s->init;
	word size = s->height;
	word size2 = s->height>>1;
	word next_scanline = 320 - s->width;
	asm{
		push ds
		push di
		push si
		push dx
		///Paste destroyed bkg chunk in last frame
		cmp	word ptr [init],1 //if (s->init == 1)
		jne	short rle_noinit
		
		mov 	ax,0A000h
		mov 	es,ax						
		mov		di,screen_offset0				
		
		lds		bx,[bkg_data]					
		lds		si,ds:[bx]						
		mov 	ax,size
	}
	rle_1:	
	asm{
		mov 	cx,size2
		rep		movsw				// copy bytes from ds:si to es:di
		add 	di,[next_scanline]
		dec 	ax
		jnz		rle_1
	}
	rle_noinit:
	s->init = 1;
	
	/*Copy bkg chunk before destroying it*/
	asm{
		mov 	ax,0A000h
		mov 	ds,ax						
		mov		si,screen_offset1				
		
		les		bx,[bkg_data]					
		les		di,es:[bx]						
		mov 	ax,size
	}
	rle_2:	
	asm{
		mov 	cx,size2
		rep		movsw				// copy bytes from ds:si to es:di
		add 	si,[next_scanline]
		dec 	ax
		jnz		rle_2
	
	/*copy sprite and destroy bkg*/	
		mov 	ax,0A000h
		mov 	es,ax						
		mov		di,screen_offset1	//es:di = vga		
	
		lds		bx,[data]					
		lds		si,ds:[bx]			//ds:si = data		
	
		lodsw			//DS:SI -> AX (Number of runs)
		
		xchg dx,ax		//DX = Number of runs.
	}
	rle_3:				//DX = Number of runs
	asm{
		lodsw			//DS:SI -> AX. Number of bytes to ad to pointer DI.
		add 	di,ax	
		lodsw			//DS:SI -> AX. Number of bytes of pixel data that follow
		mov 	cx,ax	//CX = AX (counter)
		shr     ax,1
		jc		rle_odd
		
		shr		cx,1	//counter / 2 because we copy words
		rep 	movsw	//copy pixel data from ds:si to es:di
		dec 	dx		//DX = Number of runs
		jnz 	rle_3
		jmp		rle_exit
	}
	rle_odd:
	asm{
		rep 	movsb	//copy pixel data from ds:si to es:di
		dec 	dx		//DX = Number of runs	
		jnz 	rle_3
	}
	rle_exit:
	asm{
		pop dx
		pop si
		pop di
		pop ds
	}
	s->last_x = x;
	s->last_y = y;
}

/*set_palette*/                                                           
void set_palette(unsigned char *palette)
{
  int i;
  outp(0x03c8,0); 
  for(i=0;i<256*3;i++) outp(0x03c9,palette[i]);
}

/*init Cycle struct*/  
void cycle_init(COLORCYCLE *cycle,unsigned char *palette){
	cycle->frame = 0;
	cycle->counter = 0;
	cycle->palette = palette;
}

/*Cycle palette*/  
void cycle_palette(COLORCYCLE *cycle, int speed){
	int i;
	if (cycle->frame == 27) cycle->frame = 3;
	outp(0x03c8,0); 
	for(i=0;i!=27;i++) outp(0x03c9,cycle->palette[i+cycle->frame]);
	if (cycle->counter == speed){cycle->counter = 0; cycle->frame+=3;}
	cycle->counter++;
}

/* draw_bitmap */
void draw_plain_bitmap(TILE *bmp,int x,int y)
{
  int j;
  word screen_offset = (y<<8)+(y<<6)+x;
  word bitmap_offset = 0;

  for(j=0;j<bmp->height;j++)
  {
    memcpy(&MCGA[screen_offset],&bmp->tdata[bitmap_offset],bmp->width);

    bitmap_offset+=bmp->width;
    screen_offset+=SCREEN_WIDTH;
  }
}

/*wait*/

void wait(int ticks)
{
  word start;
  start=*my_clock;
  while (*my_clock-start<ticks){
    *my_clock=*my_clock;
  }
}

void opl2_out(unsigned char reg, unsigned char data){
	outportb(opl2_base, reg);
	outportb(opl2_base + 1, data);
	shadow_opl[reg] = data;
}

void opl2_clear(void){
	int i;
	for (i = 0; i < 256; i++)opl2_out(i, 0);
}

void interrupt play_music(void){
	if (time_ctr > next_event){
		opl2_out(song.sdata[song.offset], song.sdata[song.offset+1]);
		next_event += (song.sdata[song.offset+2] | (song.sdata[song.offset+3]) << 8);
		song.offset+=4;
		if (song.offset > song.size)song.offset = 0;
	}
	time_ctr++;
	//outportb(0x20, 0x20);	//PIC, EOI
}

void set_timer(int freq_div){
	unsigned long spd = 1193182;
	old_time_handler = getvect(0x1C);
	spd /= freq_div;
	outportb(0x43, 0x36);
	outportb(0x40, spd % 0x100);	//lo-byte
	outportb(0x40, spd / 0x100);	//hi-byte*/
	setvect(0x1C, play_music);
}

void reset_timer(){
	outportb(0x43, 0x36);
	outportb(0x40, 0xFF);	//lo-byte
	outportb(0x40, 0xFF);	//hi-byte*/
	setvect(0x1C, old_time_handler);
}

void Load_Song(char *fname){
	FILE *imfile = fopen(fname, "rb");
	unsigned char rb[16];
	struct stat filestat;
	
	if (!imfile){
		set_mode(TEXT_MODE);
		printf("Can't find %s.\n",fname);
		exit(1);
	}
	if (fread(rb, sizeof(char), 2, imfile) != 2){
		set_mode(TEXT_MODE);
		printf("Error openning %s.\n",fname);
		exit(1);
	}
	
	//IMF
	if (rb[0] == 0 && rb[1] == 0){
		song.filetype = 0;
		song.offset = 0L;
	}
	else {
		song.filetype = 1;
		song.offset = 2L;
	}
	//get file size:
	fstat(fileno(imfile),&filestat);
    song.size = filestat.st_size;
    fseek(imfile, 0, SEEK_SET);
	
	free(song.sdata);
	if ((song.sdata = (unsigned char *) malloc(song.size)) == NULL){
		fclose(imfile);
		set_mode(TEXT_MODE);
		printf("Error allocating memory for music data %s.\n",fname);
		exit(1);
	}
	fread(song.sdata, 1, song.size,imfile);
	fclose(imfile);
}


void rle_sprite(){
	asm{
		lodsw		//Load word at address DS:SI into AX (Number of runs)
		xchg dx,ax	//exchange : DX = Number of runs
		//lodsw increments si 1 word by default, so, go to next word.
	}
	runLoop:		//DX = Number of runs
	asm{
		lodsw		//Word DS:SI to AX. Number of bytes by which to adjust output pointer DI.
		add di,ax	//	(+0, +1... or +320-16).
		lodsw		//Word DS:SI to AX. Number of bytes of pixel data that follow
		mov cx,ax	//CX = AX (counter)
		rep movsb	//copy pixel data from ds:si to es:di
		dec dx		//DX = Number of runs
		jnz runLoop
	}
}

int SIN[720] = {
 9,  9,  9,  9, 10, 10, 10, 10, 10, 10,
11, 11, 11, 11, 11, 11, 12, 12, 12, 12,
12, 12, 13, 13, 13, 13, 13, 13, 14, 14,
14, 14, 14, 14, 15, 15, 15, 15, 15, 15,
15, 16, 16, 16, 16, 16, 16, 16, 16, 17,
17, 17, 17, 17, 17, 17, 17, 17, 18, 18,
18, 18, 18, 18, 18, 18, 18, 18, 18, 19,
19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
19, 19, 19, 19, 20, 19, 19, 19, 19, 19,
19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
18, 18, 18, 18, 18, 18, 18, 18, 18, 18,
18, 17, 17, 17, 17, 17, 17, 17, 17, 17,
16, 16, 16, 16, 16, 16, 16, 16, 15, 15,
15, 15, 15, 15, 15, 14, 14, 14, 14, 14,
14, 13, 13, 13, 13, 13, 13, 12, 12, 12,
12, 12, 12, 11, 11, 11, 11, 11, 11, 10,
10, 10, 10, 10, 10, 9, 9, 9, 9, 9,
8, 8, 8, 8, 8, 8, 7, 7, 7, 7,
7, 7, 6, 6, 6, 6, 6, 6, 5, 5,
5, 5, 5, 5, 5, 4, 4, 4, 4, 4,
4, 3, 3, 3, 3, 3, 3, 3, 3, 2,
2, 2, 2, 2, 2, 2, 2, 2, 1, 1,
1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
1, 2, 2, 2, 2, 2, 2, 2, 2, 2,
3, 3, 3, 3, 3, 3, 3, 3, 4, 4,
4, 4, 4, 4, 4, 5, 5, 5, 5, 5,
5, 6, 6, 6, 6, 6, 6, 7, 7, 7,
7, 7, 7, 8, 8, 8, 8, 8, 8, 9,
 9,  9,  9,  9, 10, 10, 10, 10, 10, 10,
11, 11, 11, 11, 11, 11, 12, 12, 12, 12,
12, 12, 13, 13, 13, 13, 13, 13, 14, 14,
14, 14, 14, 14, 15, 15, 15, 15, 15, 15,
15, 16, 16, 16, 16, 16, 16, 16, 16, 17,
17, 17, 17, 17, 17, 17, 17, 17, 18, 18,
18, 18, 18, 18, 18, 18, 18, 18, 18, 19,
19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
19, 19, 19, 19, 20, 19, 19, 19, 19, 19,
19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
18, 18, 18, 18, 18, 18, 18, 18, 18, 18,
18, 17, 17, 17, 17, 17, 17, 17, 17, 17,
16, 16, 16, 16, 16, 16, 16, 16, 15, 15,
15, 15, 15, 15, 15, 14, 14, 14, 14, 14,
14, 13, 13, 13, 13, 13, 13, 12, 12, 12,
12, 12, 12, 11, 11, 11, 11, 11, 11, 10,
10, 10, 10, 10, 10, 9, 9, 9, 9, 9,
8, 8, 8, 8, 8, 8, 7, 7, 7, 7,
7, 7, 6, 6, 6, 6, 6, 6, 5, 5,
5, 5, 5, 5, 5, 4, 4, 4, 4, 4,
4, 3, 3, 3, 3, 3, 3, 3, 3, 2,
2, 2, 2, 2, 2, 2, 2, 2, 1, 1,
1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
1, 2, 2, 2, 2, 2, 2, 2, 2, 2,
3, 3, 3, 3, 3, 3, 3, 3, 4, 4,
4, 4, 4, 4, 4, 5, 5, 5, 5, 5,
5, 6, 6, 6, 6, 6, 6, 7, 7, 7,
7, 7, 7, 8, 8, 8, 8, 8, 8, 9
};
