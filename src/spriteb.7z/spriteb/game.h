/**************************************************************************
 * original from bitmap.c                                                 *
 * written by David Brackeen                                              *
 * http://www.brackeen.com/home/vga/                                      *
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include <mem.h>
#undef outp

#define SCREEN_WIDTH        320       // width in pixels of mode 0x13
#define SCREEN_HEIGHT       200       // height in pixels of mode 0x13

typedef unsigned char  byte;
typedef unsigned short word;

byte *VGA=(byte *)0xA0000000L;        /* this points to video memory. */

typedef struct tagBITMAP              /* the structure for a bitmap. */
{
	word width;
	word height;
	byte *data;
	unsigned char palette[256*3];
} BITMAP;

typedef struct tagSPRITE              /* the structure for a sprite. */
{
	word width;
	word height;
	byte *data;
	byte *bkg_data;
	int init; 
  	int last_x;
	int last_y;
} SPRITE;


void fskip(FILE *fp, int num_bytes)
{
   int i;
   for (i=0; i<num_bytes; i++)
      fgetc(fp);
}

/**************************************************************************
 *  set_mode                                                              *
 *     Sets the video mode.                                               *
 **************************************************************************/

void set_mode(byte mode)
{
	union REGS regs;
	regs.h.ah = 0x00;
	regs.h.al = mode;
	int86(0x10, &regs, &regs);
}

//load_bmp
void load_bmp(char *file,BITMAP *b)
{
	FILE *fp;
	long index;
	word num_colors;
	int x;

	fp = fopen(file,"rb");
	fgetc(fp);
	fgetc(fp);

	fskip(fp,16);
	fread(&b->width, sizeof(word), 1, fp);
	fskip(fp,2);
	fread(&b->height,sizeof(word), 1, fp);
	fskip(fp,22);
	fread(&num_colors,sizeof(word), 1, fp);
	fskip(fp,6);

	if (num_colors==0) num_colors=256;
	if ((b->data = (byte *) malloc((word)(b->width*b->height))) == NULL){
		fclose(fp);
		printf("Error allocating memory for file %s.\n",file);
		exit(1);
	}

	for(index=0;index<num_colors;index++){
		b->palette[(int)(index*3+2)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+1)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+0)] = fgetc(fp) >> 2;
		x=fgetc(fp);
	}

	for(index=(b->height-1)*b->width;index>=0;index-=b->width)
		for(x=0;x<b->width;x++)
		b->data[(word)index+x]=(byte)fgetc(fp);

	fclose(fp);
}

void load_sprite(SPRITE *s,BITMAP *b){
	s->data = b->data; 
	s->bkg_data = (byte *) malloc((word)(256)); /*allocate memory for the 16x16 bkg chunk erased every time you draw the sprite*/
	s->init = 0;
	s->height = b->height;
	s->width = b->width;
}


//set_palette                                                           
void set_palette(unsigned char *palette)
{
  int i;
  outp(0x03c8,0); 
  for(i=0;i<256*3;i++) outp(0x03c9,palette[i]);
}

//draw_bitmap
void draw_bitmap(BITMAP *bmp,int x,int y)
{
  int j;
  word screen_offset = (y<<8)+(y<<6)+x;
  word bitmap_offset = 0;

  for(j=0;j<bmp->height;j++)
  {
    memcpy(&VGA[screen_offset],&bmp->data[bitmap_offset],bmp->width);
    bitmap_offset+=bmp->width;
    screen_offset+=SCREEN_WIDTH;
  }
}

void draw_sprite(SPRITE *s,int x,int y){
	int i = 0;
	int j = 0;
	word screen_offset; 
	word bitmap_offset = 0;
 
	//Paste destroyed bkg chunk in last frame
	if (s->init == 1){
		i = 0;
		screen_offset = (s->last_y<<8)+(s->last_y<<6)+s->last_x;
		for(j=0;j<16;j++){
			memcpy(&VGA[screen_offset],&s->bkg_data[i],16);
			screen_offset+=SCREEN_WIDTH;
			i+=16;
		}
		s->init = 2;
	}
	s->init = 1;
	
	//Copy bkg chunk before destroying it
	i = 0;
	screen_offset = (y<<8)+(y<<6)+x;
	for(j=0;j<16;j++){
		memcpy(&s->bkg_data[i],&VGA[screen_offset],16);
		screen_offset+=SCREEN_WIDTH;
		i+=16;
	}

	//copy sprite and destroy bkg
	screen_offset = (y<<8)+(y<<6)+x;
	for(j=0;j<16;j++){
		memcpy(&VGA[screen_offset],&s->data[bitmap_offset],16);
		bitmap_offset+=16;
		screen_offset+=SCREEN_WIDTH;
	}
	s->last_x = x;
	s->last_y = y;
}
