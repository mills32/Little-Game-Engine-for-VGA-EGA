/**************************************************************************
 *																		  *
 * Sprite Test for MCGA/VGA mode 13										  *
 *																		  *
 **************************************************************************/

#include "game.h"

//VGA[0] = spr->data[0]; Working, (see the pink pixel at the top left corner on the screen)
void test_function(SPRITE *spr); 

//copy a scanline of the sprite from spr->data[0] to VGA[0]; Not working
void test_function2(SPRITE *spr); 

void main(){

	BITMAP tileset,spr1,spr2,spr3;		// 1 tileset and 3 sprites
	SPRITE sprite,sprite1,sprite2;

	int i = 0;
	int j = 0;
	int x = 0;
	
	printf("Loading");
	load_bmp("tile.bmp",&tileset);		// Load a tileset
	load_bmp("sprite.bmp",&spr1);		// Load data for the sprite 1
	load_sprite(&sprite,&spr1);			// init the sprite 0 with spr1 data
	
	set_mode(0x13);       // set the video mode.
	set_palette(&tileset.palette);
	
	//Draw a map
	for (j=0;j<200;j+=8){
		for (i=0;i<320;i+=8)draw_bitmap(&tileset,i,j);
	}
	
	i = 0;
	//MAIN LOOP 
	while(i < 700){
		
		draw_sprite(&sprite,x,100);
		test_function(&sprite);
		//test_function2(&sprite);
		x++;i++;
		
		//waits for vertical sync
		while ((inp(0x03da) & 0x08));
		while (!(inp(0x03da) & 0x08));
	}
	
	free(tileset.data);                     // free up memory used
	free(spr1.data);
	set_mode(0x03);                	// set the video mode back to text mode
	printf("end\n");
	return;
}
