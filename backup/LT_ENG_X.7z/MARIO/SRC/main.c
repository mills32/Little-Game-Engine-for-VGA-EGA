/***********************
*  LITTLE GAME ENGINE  *
*	TEST
************************/
#include "lt__eng.h"

int Scene = 0;

LT_Col LT_Player_Col;

void Load_Platform(){
	LT_Set_Loading_Interrupt(); 

	Scene = 2;
	LT_Load_Map("GFX/mario.tmx");
	LT_Load_Tiles("GFX/mariotil.bmp");
	LT_Load_Sprite("GFX/s_mario.bmp",16,16);
	LT_Load_Sprite("GFX/goomba.bmp",17,16);
	LT_Clone_Sprite(18,17);
	LT_Clone_Sprite(19,17);
	LT_Clone_Sprite(20,17);
	LT_Clone_Sprite(21,17);
	LT_Clone_Sprite(22,17);
	LT_Clone_Sprite(23,17);
	
	LT_Load_Music("music/mario2.imf");
	
	LT_Delete_Loading_Interrupt();
	
	LT_Start_Music(70);
	
	LT_MODE = 1;//platform
}

void Run_Platform(){
	int n;
	startp:
	Scene = 2;
	sprite[16].pos_x = 16*10;
	sprite[16].pos_y = 0;
	
	//Place enemies manually on map in tile units (x16)
	//They will be drawn only if they are inside viewport.
	LT_Set_Enemy(17,22,10,-1,0);
	LT_Set_Enemy(18,32,14,1,0);
	LT_Set_Enemy(19,53,14,-1,0);
	LT_Set_Enemy(20,78,10,-1,0);
	LT_Set_Enemy(21,103,14,1,0);
	LT_Set_Enemy(22,171,10,-1,0);
	LT_Set_Enemy(23,201,14,1,0);
	
	LT_Set_Map(0,0);
	
	while(Scene == 2){
		LT_WaitVsyncEnd();
	
		LT_scroll_follow(16);
		
		//Restore BKG
		for (n = 23; n != 16; n--) LT_Restore_Enemy_BKG(n);
		LT_Restore_Sprite_BKG(16);
		
		//Draw sprites first to avoid garbage
		LT_Draw_Sprite(16);
		for (n = 17; n != 24; n++)LT_Draw_Enemy(n);
		
		LT_scroll_map();
		
		//In this mode sprite 16 is controlled using L R and Jump
		LT_Player_Col = LT_move_player(16);
		
		if (LT_Keys[LT_RIGHT]) LT_Set_Sprite_Animation(16,0,4,4);
		else if (LT_Keys[LT_LEFT]) LT_Set_Sprite_Animation(16,6,4,4);
		else sprite[16].animate = 0;
		
		//if (sprite_player.ground == 0) sprite_player.frame = 4;
		if (LT_Keys[LT_ESC])  Scene = -1; //esc exit
		
		//Move the enemy
		for (n = 17; n != 24; n++) LT_Enemy_walker(n,1);
		
		//Flip
		for (n = 17; n != 24; n++){
			if (sprite[n].speed_x > 0) LT_Set_Sprite_Animation(n,2,2,5);
			if (sprite[n].speed_x < 0) LT_Set_Sprite_Animation(n,0,2,5);	
		}
		
		//fall
		if (sprite[16].pos_y > 16<<4) { VGA_Fade_out(); sprite[16].init = 0; goto startp;}
		
		//Found castle
		if (LT_Player_Col.tilecol_number == 11) {
			Scene = -1;
		}
		
		LT_WaitVsyncStart();
	}
	
	LT_unload_sprite(16); //manually free sprites
	LT_unload_sprite(17); //manually free sprites
}


void main(){
	
	system("cls");
	LT_Init();
	
	
	//You can use a custom loading animation for the Loading_Interrupt
	LT_Load_Animation("GFX/loading.bmp",32);
	LT_Set_Animation(0,4,6);
	
	Load_Platform();
	Run_Platform();
	
	LT_ExitDOS(); //frees map, tileset, font and music.
	
	return;
}