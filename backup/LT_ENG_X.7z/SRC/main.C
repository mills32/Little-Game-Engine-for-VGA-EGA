/*************************************************************************



**************************************************************************/


#include "lt__eng.h"

//This points to video memory.
byte *VGA2=(byte *)0xA0000000L; 

void draw_tile(word x, word y, word tile){
	word screen_offset = (y<<6)+(y<<4)+(y<<2)+(x>>2);
	tile = tile*64;
	outport(SC_INDEX, ((word)0xff << 8) + MAP_MASK); //select all planes
    outport(GC_INDEX, 0x08); 
	
	asm{
		push ds
		push di
		push si	
		
		mov 	ax,0A000h
		mov 	ds,ax						
		mov		si,0C240h 		//590*(336/4);	ds:si Tile data VRAM address = FIXED VRAM AT scan line 590; 

		mov		ax,word ptr[tile]
		add		si,ax
		
		mov 	ax,0A000h
		mov 	es,ax
		mov		di,screen_offset		//es:di destination VRAM address							
	}
	//UNWRAPPED LOOP
	asm{//COPY TILE
		mov 	cx,4		//COPY TILE (16 LINES)
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80	//END COPY TILE
	}
	
	asm{//END	
		pop si
		pop di
		pop ds
	}
	
	outport(GC_INDEX + 1, 0x0ff);
}

void Colorize_VRAM(){
	long offset;
	int i;
	
	outport(0x03c4,0xff02);
	
	offset = 0;
	memset(&VGA2[offset],154,1344);
	
	offset = 528*(336/4);
	memset(&VGA2[offset],122,1344);
	
	outport(0x03c4,0xff02);
	offset = 544*(336/4);
	memset(&VGA2[offset],139,1024);
	
	outport(0x03c4,0xff02);
	offset = 560*(336/4);
	memset(&VGA2[offset],140,1024);
	
	outport(0x03c4,0xff02);
	offset = 576*(336/4);
	memset(&VGA2[offset],141,1024);
}

void main(){
	int Scene = 0; 
	int x = 0; int y = 0; int t = 0;
	
	SPRITE ship;
	
    LT_init();
	
	VGA_ClearScreen();
	
	//33 fixed sprites:
	//	8x8   (16 sprites: 0 - 15)	
	//	16x16 (12 sprites: 16 - 28)
	//	32x32 ( 4 sprites: 29 - 32)
	//	64x64 ( 1 sprite: 33)
	
	LT_Load_Sprite("GFX/ship.bmp",29,32);
	LT_Load_Sprite("GFX/ship.bmp",30,32);
	
	LT_Load_Tiles("GFX/platil.bmp");
	
	set_palette(LT_tileset.palette);
	
	VGA_Scroll(0,0);
	
	Colorize_VRAM();
	
	for (y = 0; y < 18; y++){
		for (x = 0; x < 13;x++) {
			draw_tile(x<<4,y<<4,t);
			t++;
		}
	}
	
	x = 0; y = 0;
	LT_Set_Sprite_Animation(29, 4, 4, 4);
	LT_Set_Sprite_Animation(30, 8, 4, 4);
	while (Scene == 0){
		
		LT_WaitVsyncEnd();
		VGA_Scroll(x,y);
		
		LT_Restore_Sprite_BKG(29);
		LT_Restore_Sprite_BKG(30);
		
		sprite[29].pos_x = x+80;
		sprite[29].pos_y = y+80;
		sprite[30].pos_x = x + 120;
		sprite[30].pos_y = y + 120;
		
		LT_Draw_Sprite(29);
		LT_Draw_Sprite(30);

		if (LT_Keys[LT_LEFT]) x--;
		if (LT_Keys[LT_RIGHT]) x++;
		if (LT_Keys[LT_DOWN]) y++;
		if (LT_Keys[LT_UP]) y--;
		if (LT_Keys[LT_ESC]) Scene = 1;		
		
		LT_WaitVsyncStart();
	}
    
	LT_ExitDOS();
	
}

