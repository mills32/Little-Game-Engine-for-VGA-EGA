/*************************************************************************



**************************************************************************/


#include "lt__eng.h"

//This points to video memory.
byte *VGA=(byte *)0xA0000000L; 

int x_compile_bitmap(word logical_screen_width, char *bitmap, char *output);       
void x_run_compiled_sprite(word XPos, word YPos, char *CompiledBitmap);

void draw_tile(word x, word y, word tile){
	word screen_offset = (y*84)+(x>>2);
	tile = tile*64;
	outport(SC_INDEX, ((word)0xff << 8) + MAP_MASK); //select all planes
    outport(GC_INDEX, 0x08); 
	
	asm{
		push ds
		push di
		push si	
		
		mov 	ax,0A000h
		mov 	ds,ax						
		mov		si,0C240h 		//590*(336/4);	ds:si Tile data VRAM address = FIXED VRAM AT scan line 590; 

		mov		ax,word ptr[tile]
		add		si,ax
		
		mov 	ax,0A000h
		mov 	es,ax
		mov		di,screen_offset		//es:di destination VRAM address							
	}
	//UNWRAPPED LOOP
	asm{//COPY TILE
		mov 	cx,4		//COPY TILE (16 LINES)
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80
		mov 	cx,4
		rep		movsb				
		add 	di,80	//END COPY TILE
	}
	
	asm{//END	
		pop si
		pop di
		pop ds
	}
	
	outport(GC_INDEX + 1, 0x0ff);
}

void Colorize_VRAM(){
	long offset;
	int i;
	
	outport(0x03c4,0xff02);
	
	offset = 0;
	memset(&VGA[offset],154,1344);
	
	offset = 528*(336/4);
	memset(&VGA[offset],122,1344);
	
	outport(0x03c4,0xff02);
	offset = 544*(336/4);
	memset(&VGA[offset],139,1024);
	
	outport(0x03c4,0xff02);
	offset = 560*(336/4);
	memset(&VGA[offset],140,1024);
	
	outport(0x03c4,0xff02);
	offset = 576*(336/4);
	memset(&VGA[offset],141,1024);
}

void main(){
	int Scene = 0; 
	int x = 0; int y = 0; int s = 0; int f = 0; int t = 0;
	
	SPRITE ship;
	
    LT_init();
	
	VGA_ClearScreen();
	
	LT_Load_Sprite("GFX/ship.bmp",&ship,32);
	
	LT_Load_Tiles("GFX/platil.bmp");
	
	set_palette(LT_tileset.palette);
	
	VGA_Scroll(0,0);
	
	Colorize_VRAM();
	
	for (y = 0; y < 18; y++){
		for (x = 0; x < 13;x++) {
			draw_tile(x<<4,y<<4,t);
			t++;
		}
	}
	
	x = 0; y = 0;
	while (Scene == 0){
		
		LT_WaitVsyncEnd();
		
		VGA_Scroll(x,y);
		
		if (s == 8){s = 0; f++;}
		if (f == 16) f = 0;
		x_run_compiled_sprite(32, y+32,ship.frames[f].compiled_code);
		s++;
		
		y++;
		
		LT_WaitVsyncStart();
		
		if (LT_Keys[LT_ESC]) Scene = 1;
	}
    
	farfree(ship.frames[0].compiled_code);
	LT_ExitDOS();
	
}

