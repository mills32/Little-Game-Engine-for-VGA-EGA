/***********************
*  LITTLE GAME ENGINE  *
************************/

/*##########################################################################
	A lot of code from David Brackeen                                   
	http://www.brackeen.com/home/vga/                                     

	Sprite loader and bliter from xlib
	
	This is a 16-bit program, Remember to compile in the LARGE memory model!                        
	
	All code is 8086 / 8088 compatible
	
	Please feel free to copy this source code.                            
	

	LT_MODE = player movement modes

	//MODE TOP = 0;
	//MODE PLATFORM = 1;
	//MODE PUZZLE = 2;
	//MODE SIDESCROLL = 3;
	
	//33 fixed sprites:
	//	8x8   (16 sprites: 0 - 15)	
	//	16x16 (12 sprites: 16 - 28)
	//	32x32 ( 4 sprites: 29 - 32)
	//	64x64 ( 1 sprite: 33)
	
##########################################################################*/

#include "lt__eng.h"

unsigned char palette_cycle_water[] = {//generated with gimp, then divided by 4 (max = 64).
	//2 copies of 8 colour cycle
	0x35,0x3b,0x3f,//
	0x26,0x39,0x3f,
	0x18,0x36,0x3f,
	0x09,0x32,0x3e,
	0x0f,0x34,0x3f,
	0x17,0x36,0x3f,
	0x1c,0x3a,0x3e,
	0x24,0x3e,0x3d,
	0x35,0x3b,0x3f,//
	0x26,0x39,0x3f,
	0x18,0x36,0x3f,
	0x09,0x32,0x3e,
	0x0f,0x34,0x3f,
	0x17,0x36,0x3f,
	0x1c,0x3a,0x3e,
	0x24,0x3e,0x3d,
	0x35,0x3b,0x3f
};

LT_Col LT_Player_Col;

int x,y = 0;
int i,j = 0;
int Scene = 0;
int menu_option = 0;
int menu_pos[10] = {7.3*16,4*16,7.3*16,5*16,7.3*16,6*16,7.3*16,7*16,7.3*16,8*16};
int game = 0;
int random;


void Load_Logo(){
	LT_Load_Map("GFX/Logo.tmx");
	LT_Load_Tiles("GFX/Logotil.bmp");
	VGA_Fade_out();
	LT_Set_Map(0,0);
}

void Run_Logo(){
	while (y < 144){
		LT_WaitVsyncEnd();
		VGA_Scroll(x,y);
		LT_scroll_map();
		y++;
		if (LT_Keys[LT_ESC]) {VGA_Scroll(0,0); goto exit;}//esc exit
		LT_WaitVsyncStart();
	}
	exit:
	sleep(1);
}

void Load_Menu(){
	//LT_Set_Loading_Interrupt(); 
	
	LT_Load_Map("GFX/menu.tmx");
	LT_Load_Tiles("GFX/menutil.bmp");
	LT_Load_Sprite("GFX/cursor.bmp",16,16);
	//LT_Load_Music("music/menu2.imf");
	//LT_Start_Music(70);
	LT_LoadMOD("MUSIC/MOD/dyna.mod"); 
	
	//LT_Delete_Loading_Interrupt();
	
	PlayMOD(0);
	
	VGA_SplitScreen(96); 
	VGA_Scroll(0,0);
	LT_Set_Map(0,0);
	
	i = 0;
	LT_MODE = 0;
}

void Run_Menu(){
	int delay = 0; //wait between key press
	Scene = 1;
	game = 0;
	menu_option = 0;
	
	x = 0;
	y = 0;
	
	LT_Set_Sprite_Animation(16,0,8,6);
	while(Scene == 1){
		LT_WaitVsyncEnd();
		
		VGA_Scroll(x,0); //Scroll split tittle
		x = -54-(LT_SIN[i]>>1);
		
		sprite[16].pos_x = menu_pos[menu_option] + (LT_COS[j]>>3);
		sprite[16].pos_y = menu_pos[menu_option+1];
		
		LT_Restore_Sprite_BKG(16);
		LT_Draw_Sprite(16);
		
		if (i > 360) i = 0;
		i+=2;
		if (j > 356) {j = 0; sprite[16].anim_counter = 0;}
		j+=8;
		
		if (delay == 10){
			if (LT_Keys[LT_UP]) {menu_option -=2; game--;}
			if (LT_Keys[LT_DOWN]) {menu_option +=2; game++;}
			delay = 0;
		}
		delay++;
		
		if (menu_option < 0) menu_option = 0;
		if (menu_option > 8) menu_option = 8;		
		if (game < 0) game = 0;
		if (game > 4) game = 4;	
		
		if (LT_Keys[LT_ENTER]) Scene = 2;
		if (LT_Keys[LT_ESC]) {
			LT_unload_sprite(16);
			LT_ExitDOS();
		}
		
		LT_WaitVsyncStart();
	}
	StopMOD();
	LT_unload_sprite(16);
	VGA_SplitScreen(0x0ffff);
}


void main(){
	int Scene = 0; 
	int x = 0; int y = 0; int t = 0;
	
	system("cls");
	//LT_Check_CPU(); //still causing trouble
	//LT_Adlib_Detect(); 
	LT_Init_GUS(12);
	gotoxy(17,13);
	printf("LOADING");
	gotoxy(0,0);
    LT_init();
	
	Load_Logo();
	Run_Logo();
	
	LT_MODE = 0;
	
	//MENU
	menu:
	
	Load_Menu();
	Run_Menu();
	
	
	LT_Load_Sprite("GFX/ship.bmp",29,32);
	LT_Load_Sprite("GFX/ship.bmp",30,32);
	
	LT_Load_Map("GFX/platform.tmx");
	LT_Load_Tiles("GFX/platil.bmp");
	//VGA_Fade_out();
	
	LT_Set_Map(0,0);
	
	VGA_Scroll(0,0);
	x = 0; y = 0;
	LT_Set_Sprite_Animation(29, 4, 4, 4);
	LT_Set_Sprite_Animation(30, 8, 4, 4);
	while (Scene == 0){
		
		LT_WaitVsyncEnd();
		VGA_Scroll(x,y);
		
		LT_Restore_Sprite_BKG(29);
		LT_Restore_Sprite_BKG(30);
		
		sprite[29].pos_x = x+80;
		sprite[29].pos_y = y+80;
		sprite[30].pos_x = x + 120;
		sprite[30].pos_y = y + 120;
		
		LT_Draw_Sprite(29);
		LT_Draw_Sprite(30);

		LT_scroll_map();
	
		
		if (LT_Keys[LT_LEFT]) x--;
		if (LT_Keys[LT_RIGHT]) x++;
		if (LT_Keys[LT_DOWN]) y++;
		if (LT_Keys[LT_UP]) y--;
		if (LT_Keys[LT_ESC]) Scene = 1;		
		
		LT_WaitVsyncStart();
	}
    
	LT_ExitDOS();
	
}

