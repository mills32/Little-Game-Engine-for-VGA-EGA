/*---------------------------------------------------------------------------------
	
	BMP2RLE: convert a BMP file to RLS sprite for Little Engine

---------------------------------------------------------------------------------*/

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys\stat.h> //use stat to get correct file size
#include <dos.h>
#include <mem.h>
#undef outp
#define SCREEN_WIDTH        320
typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned long  dword;
byte *MCGA=(byte *)0xA0000000L; 

//
byte *sprite_datatemp; // these are used to rearrange a sprite sheet in memory
byte *sprite_tiledatatemp; // these are used to rearrange a sprite sheet in memory

typedef struct tagSPRITE					/* the structure for a bitmap. */
{
	word width;
	word height;
	word ntiles;
	byte palette[256*3];
	byte *rle_data;
} SPRITE;



typedef struct tagTILE					/* the structure for a bitmap. */
{
	word width;
	word height;
	word ntiles;
	byte palette[256*3];
	byte *datatemp;
	byte *tdata;
} TILE;

SPRITE ship;
TILE bmp;

int counter = 0;
void set_mode(byte mode)
{
	union REGS regs;
	regs.h.ah = 0x00;
	regs.h.al = mode;
	int86(0x10, &regs, &regs);
}

/*set_palette*/                                                           
void set_palette(unsigned char *palette)
{
  int i;
  outp(0x03c8,0); 
  for(i=0;i<256*3;i++) outp(0x03c9,palette[i]);
}

void fskip(FILE *fp, int num_bytes){
	int i;
	for (i=0; i<num_bytes; i++) fgetc(fp);
}

/* load_32x32 tiles for bigger sprites */
void load_sprite_RLE(char *file,SPRITE *b,int size){
	FILE *fp;
	long index,offset;
	word num_colors;
	int x,y,i;
	int tileX;
	int tileY;
	byte *data;	//Temp storage of non tiled data.
	
	word number_of_runs = 0;
	int skip = 0;
	int foffset = 0; //offset in final data
	int frame_size;
	int run_sskip[1024];
	int run_bskip[1024];
	int run_startx[1024];
	int run_length[1024];
	byte current_byte;
	byte last_byte = 0;
	
	
	fp = fopen(file,"rb");
	if(!fp){
		printf("can't find %s.\n",file);
		exit(1);
	} 
	fgetc(fp);
	fgetc(fp);

	fskip(fp,16);
	fread(&b->width, sizeof(word), 1, fp);
	fskip(fp,2);
	fread(&b->height,sizeof(word), 1, fp);
	fskip(fp,22);
	fread(&num_colors,sizeof(word), 1, fp);
	fskip(fp,6);

	if (num_colors==0) num_colors=256;
	for(index=0;index<num_colors;index++){
		b->palette[(int)(index*3+2)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+1)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+0)] = fgetc(fp) >> 2;
		x=fgetc(fp);
	}
	
	if ((sprite_datatemp = (byte *) malloc(b->width*b->height)) == NULL){
		fclose(fp);
		printf("Error allocating memory for temp data %s.\n",file);
		exit(1);
	}
	if ((sprite_tiledatatemp = (byte *) malloc(b->width*b->height)) == NULL){
		fclose(fp);
		printf("Error allocating memory tile data %s.\n",file);
		exit(1);
	}

	for(index=(b->height-1)*b->width;index>=0;index-=b->width)
		for(x=0;x<b->width;x++)
		sprite_datatemp[(word)index+x]=(byte)fgetc(fp);
	fclose(fp);

	index = 0;
	
	//Rearrange tiles one after another in memory (in a column)
	for (tileY=0;tileY<b->height;tileY+=size){
		for (tileX=0;tileX<b->width;tileX+=size){
			offset = (tileY*b->width)+tileX;
			for(x=0;x<size;x++){
				memcpy(&sprite_tiledatatemp[index],&sprite_datatemp[offset+(x*b->width)],size);
				index+=size;
			}
		}
	}
	b->ntiles = (b->width>>4) * (b->height>>4);
	b->width = size;
	b->height = size;
	free(sprite_datatemp);
	sprite_datatemp = NULL;
	
	//CONVERT TO RLE
	offset = 0;
	run_sskip[0] = 0;
	for(y = 0; y < size; y++) {
		last_byte = 0;
		for(x = 0; x < size; x++) {
			current_byte = sprite_tiledatatemp[(size*y)+x];
			if (last_byte == 0 && current_byte > 0)run_startx[number_of_runs] = x;
			if (last_byte != 0 && current_byte == 0){
				run_length[number_of_runs] = x - run_startx[number_of_runs]; 
				if (number_of_runs == 0){
					run_sskip[0] = run_startx[0];
					run_bskip[0] = run_startx[0];
				}
				if (number_of_runs > 0){
					if (skip == 0){
						run_sskip[number_of_runs] = skip+run_startx[number_of_runs]-(run_startx[number_of_runs-1]+run_length[number_of_runs-1]);
						run_bskip[number_of_runs] = skip+run_startx[number_of_runs]-(run_startx[number_of_runs-1]+run_length[number_of_runs-1]);
					}
					if (skip == 1){
						run_sskip[number_of_runs] = 320+run_startx[number_of_runs]-(run_startx[number_of_runs-1]+run_length[number_of_runs-1]);
						run_bskip[number_of_runs] = size+run_startx[number_of_runs]-(run_startx[number_of_runs-1]+run_length[number_of_runs-1]);
						skip = 0;
					}
					if (skip == 2){
						run_sskip[number_of_runs] = 320-size;
						run_bskip[number_of_runs] = 0;
						skip = 0;
					}
				}
				number_of_runs++;
			}
			last_byte = current_byte;
		}
		if (current_byte == 0)skip = 1;
		if (current_byte > 0){
			run_length[number_of_runs] = x - run_startx[number_of_runs];
			if (number_of_runs > 0){
				run_sskip[number_of_runs] = 320+run_startx[number_of_runs]-(run_startx[number_of_runs-1]+run_length[number_of_runs-1]);
				run_bskip[number_of_runs] = size+run_startx[number_of_runs]-(run_startx[number_of_runs-1]+run_length[number_of_runs-1]);
			}
			number_of_runs++;
			skip = 2;
		}
	}
	frame_size = 2; //word "number of runs"
	for(i = 0; i < number_of_runs; i++) 
		frame_size+= (4 + run_length[i]); //word skip + word number of pixels + length
	b->rle_data = (byte *) malloc(frame_size);
	
	//copy RLE data to struct
	memcpy(&b->rle_data[0],&number_of_runs,2);
	foffset+=2;
	for(i = 0; i < number_of_runs; i++) {
		memcpy(&b->rle_data[foffset],&run_sskip[i],2); //bytes to skip on vga screen
		foffset+=2;
		memcpy(&b->rle_data[foffset],&run_length[i],2); //Number of bytes of pixel data that follow
		foffset+=2;
		offset+=run_bskip[i];
		memcpy(&b->rle_data[foffset],&sprite_tiledatatemp[offset],run_length[i]); //copy pixel data;
		foffset+=run_length[i];
		offset+=run_length[i];
	}

	free(sprite_tiledatatemp);
	sprite_tiledatatemp = NULL;
}	

void draw_sprite(SPRITE *b){
	word *data = &b->rle_data;
	asm{
		push ds
		push di
		push si
		push dx
		
		mov 	ax,0A000h
		mov 	es,ax						
		mov		di,0			//es:di = vga		
	
		lds		bx,[data]					
		lds		si,ds:[bx]		//ds:si = data		

		lodsw		//Load word at address DS:SI into AX (Number of runs)
		xchg dx,ax	//exchange : DX = Number of runs
		//lodsw increments si 1 word by default, so, go to next word.
	}
	runLoop:		//DX = Number of runs
	asm{
		lodsw		//Word DS:SI to AX. Number of bytes by which to adjust output pointer DI.
		add di,ax	//	(+0, +1... or +320-16).
		lodsw		//Word DS:SI to AX. Number of bytes of pixel data that follow
		mov cx,ax	//CX = AX (counter)
		rep movsb	//copy pixel data from ds:si to es:di
		dec dx		//DX = Number of runs
		jnz runLoop
		
		pop dx
		pop si
		pop di
		pop ds
	}
}

/* load plain bmp */
void load_plain_bmp(char *file,TILE *b)
{
	FILE *fp;
	long index;
	word num_colors;
	int x;

	fp = fopen(file,"rb");
	if(!fp){
		printf("can't find %s.\n",file);
		exit(1);
	}
	fgetc(fp);
	fgetc(fp);

	fskip(fp,16);
	fread(&b->width, sizeof(word), 1, fp);
	fskip(fp,2);
	fread(&b->height,sizeof(word), 1, fp);
	fskip(fp,22);
	fread(&num_colors,sizeof(word), 1, fp);
	fskip(fp,6);

	if (num_colors==0) num_colors=256;
	if ((b->tdata = (byte *) malloc(b->width*b->height)) == NULL){
		fclose(fp);
		printf("Error allocating memory for file %s.\n",file);
		exit(1);
	}

	for(index=0;index<num_colors;index++){
		b->palette[(int)(index*3+2)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+1)] = fgetc(fp) >> 2;
		b->palette[(int)(index*3+0)] = fgetc(fp) >> 2;
		x=fgetc(fp);
	}

	for(index=(b->height-1)*b->width;index>=0;index-=b->width)
		for(x=0;x<b->width;x++)
		b->tdata[(word)index+x]=(byte)fgetc(fp);

	fclose(fp);
}

/* draw_bitmap */
void draw_plain_bitmap(TILE *bmp,int x,int y)
{
  int j;
  word screen_offset = (y<<8)+(y<<6)+x;
  word bitmap_offset = 0;

  for(j=0;j<bmp->height;j++)
  {
    memcpy(&MCGA[screen_offset],&bmp->tdata[bitmap_offset],bmp->width);

    bitmap_offset+=bmp->width;
    screen_offset+=SCREEN_WIDTH;
  }
}

int main() {
	word test;
	load_sprite_RLE("ship1.bmp",&ship,32);
	load_plain_bmp("stileset.bmp",&bmp);
	set_mode(0x13);
	set_palette(&bmp.palette);
	draw_plain_bitmap(&bmp,0,0);
	draw_sprite(&ship);
	
	while (counter < 200){
		counter++;
		while ((inp(0x03da) & 0x08));
		while (!(inp(0x03da) & 0x08));
	}
	set_mode(0x03); 
	free(&ship);
	free(&bmp);
	return 0;
}
/*
void rle_sprite(){
	asm{
		lodsw		//Load word at address DS:SI into AX (Number of runs)
		xchg dx,ax	//exchange : DX = Number of runs
		//lodsw increments si 1 word by default, so, go to next word.
	}
	runLoop:		//DX = Number of runs
	asm{
		lodsw		//Word DS:SI to AX. Number of bytes by which to adjust output pointer DI.
		add di,ax	//	(+0, +1... or +320-16).
		lodsw		//Word DS:SI to AX. Number of bytes of pixel data that follow
		mov cx,ax	//CX = AX (counter)
		rep movsb	//copy pixel data from ds:si to es:di
		dec dx		//DX = Number of runs
		jnz runLoop
	}
}
*/
